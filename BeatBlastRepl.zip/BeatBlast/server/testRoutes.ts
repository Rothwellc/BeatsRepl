// Test routes for demo purposes
import type { Express } from "express";

export function setupTestRoutes(app: Express) {
  // Test admin route that doesn't require authentication
  app.get('/test-admin', (req, res) => {
    res.send(`
      <html>
        <head><title>Test Admin Access</title></head>
        <body style="font-family: Arial, sans-serif; padding: 20px; background: #111; color: white;">
          <h1 style="color: #ef4444;">Best Beats - Test Admin Panel</h1>
          <p>This is a test admin interface to demonstrate admin features without authentication.</p>
          
          <div style="margin: 20px 0; padding: 20px; background: #222; border-radius: 8px;">
            <h2>Pending Tracks (Demo)</h2>
            <div style="display: flex; gap: 15px; margin: 10px 0;">
              <div style="padding: 15px; background: #333; border-radius: 8px; flex: 1;">
                <h3>Night Protocol</h3>
                <p>Artist: Shadow Frequency</p>
                <p>Genre: Tech House</p>
                <p>Status: Pending Approval</p>
                <button style="background: #22c55e; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer;">Approve</button>
                <button style="background: #ef4444; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; margin-left: 10px;">Reject</button>
              </div>
              <div style="padding: 15px; background: #333; border-radius: 8px; flex: 1;">
                <h3>Digital Waves</h3>
                <p>Artist: Cyber Collective</p>
                <p>Genre: Progressive House</p>
                <p>Status: Pending Approval</p>
                <button style="background: #22c55e; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer;">Approve</button>
                <button style="background: #ef4444; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; margin-left: 10px;">Reject</button>
              </div>
            </div>
          </div>

          <div style="margin: 20px 0; padding: 20px; background: #222; border-radius: 8px;">
            <h2>Platform Analytics (Demo)</h2>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px;">
              <div style="padding: 15px; background: #333; border-radius: 8px; text-align: center;">
                <h3 style="color: #ef4444;">12,847</h3>
                <p>Total Plays</p>
              </div>
              <div style="padding: 15px; background: #333; border-radius: 8px; text-align: center;">
                <h3 style="color: #ef4444;">1,293</h3>
                <p>Active Users</p>
              </div>
              <div style="padding: 15px; background: #333; border-radius: 8px; text-align: center;">
                <h3 style="color: #ef4444;">847</h3>
                <p>Live Viewers</p>
              </div>
              <div style="padding: 15px; background: #333; border-radius: 8px; text-align: center;">
                <h3 style="color: #ef4444;">156</h3>
                <p>Total Tracks</p>
              </div>
            </div>
          </div>

          <div style="margin: 20px 0;">
            <p><a href="/" style="color: #ef4444;">← Back to Main App</a></p>
            <p style="color: #888; font-size: 14px;">Note: This is a demo interface. The real admin panel requires authentication and is available at /admin</p>
          </div>
        </body>
      </html>
    `);
  });
}