import { db } from "./db";
import { tracks, albums, users, liveStreams } from "@shared/schema";

export async function seedDatabase() {
  console.log("🌱 Seeding database with sample data...");

  try {
    // Sample albums
    const albumData = [
      {
        id: "550e8400-e29b-41d4-a716-446655440001",
        name: "Deep House Chronicles",
        coverArtUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=400&fit=crop",
        releaseDate: new Date("2024-01-15"),
      },
      {
        id: "550e8400-e29b-41d4-a716-446655440002", 
        name: "Underground Beats Vol. 1",
        coverArtUrl: "https://images.unsplash.com/photo-1571330735066-03aaa9429d89?w=400&h=400&fit=crop",
        releaseDate: new Date("2024-02-10"),
      },
      {
        id: "550e8400-e29b-41d4-a716-446655440003",
        name: "Progressive Sessions",
        coverArtUrl: "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=400&h=400&fit=crop", 
        releaseDate: new Date("2024-03-05"),
      }
    ];

    // Insert albums first
    await db.insert(albums).values(albumData).onConflictDoNothing();

    // Sample tracks
    const trackData = [
      {
        id: "650e8400-e29b-41d4-a716-446655440001",
        title: "Midnight Groove",
        artist: "DJ Phoenix",
        duration: 240,
        genre: "Deep House",
        audioUrl: "https://www.soundjay.com/misc/sounds/bell-ringing-05.wav",
        coverArtUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=400&fit=crop",
        accessType: "free" as const,
        status: "approved" as const,
        playCount: 1250,
        averageRating: "4.6",
        ratingCount: 23
      },
      {
        id: "650e8400-e29b-41d4-a716-446655440002",
        title: "Electric Dreams",
        artist: "Neon Collective",
        duration: 320,
        genre: "Progressive House",
        audioUrl: "https://www.soundjay.com/misc/sounds/bell-ringing-05.wav",
        coverArtUrl: "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=400&h=400&fit=crop",
        accessType: "paid" as const,
        status: "approved" as const,
        playCount: 890,
        averageRating: "4.8",
        ratingCount: 15
      },
      {
        id: "650e8400-e29b-41d4-a716-446655440003", 
        title: "Urban Pulse",
        artist: "Metro Bass",
        duration: 285,
        genre: "Tech House",
        audioUrl: "https://www.soundjay.com/misc/sounds/bell-ringing-05.wav",
        coverArtUrl: "https://images.unsplash.com/photo-1571330735066-03aaa9429d89?w=400&h=400&fit=crop",
        accessType: "free" as const,
        status: "approved" as const,
        playCount: 2100,
        averageRating: "4.3",
        ratingCount: 41
      },
      {
        id: "650e8400-e29b-41d4-a716-446655440004",
        title: "Sunset Vibes",
        artist: "Coastal Sound",
        duration: 200,
        genre: "Deep House",
        audioUrl: "https://www.soundjay.com/misc/sounds/bell-ringing-05.wav",
        coverArtUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=400&fit=crop",
        accessType: "paid" as const,
        status: "approved" as const,
        playCount: 3200,
        averageRating: "4.9",
        ratingCount: 67
      },
      {
        id: "650e8400-e29b-41d4-a716-446655440005",
        title: "Warehouse Anthem",
        artist: "Industrial Beats",
        duration: 380,
        genre: "Techno",
        audioUrl: "https://www.soundjay.com/misc/sounds/bell-ringing-05.wav",
        coverArtUrl: "https://images.unsplash.com/photo-1571330735066-03aaa9429d89?w=400&h=400&fit=crop",
        accessType: "free" as const,
        status: "approved" as const,
        playCount: 1750,
        averageRating: "4.4",
        ratingCount: 29
      },
      {
        id: "650e8400-e29b-41d4-a716-446655440006",
        title: "Liquid Motion",
        artist: "Flow State",
        duration: 310,
        genre: "Progressive House",
        audioUrl: "https://www.soundjay.com/misc/sounds/bell-ringing-05.wav",
        coverArtUrl: "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=400&h=400&fit=crop",
        accessType: "paid" as const,
        status: "approved" as const,
        playCount: 950,
        averageRating: "4.7",
        ratingCount: 18
      }
    ];

    // Insert tracks
    await db.insert(tracks).values(trackData).onConflictDoNothing();

    // Add some pending tracks for admin approval testing
    const pendingTracks = [
      {
        id: "650e8400-e29b-41d4-a716-446655440007",
        title: "Night Protocol",
        artist: "Shadow Frequency",
        duration: 295,
        genre: "Tech House",
        audioUrl: "https://www.soundjay.com/misc/sounds/bell-ringing-05.wav",
        coverArtUrl: "https://images.unsplash.com/photo-1571330735066-03aaa9429d89?w=400&h=400&fit=crop",
        accessType: "free" as const,
        status: "pending" as const,
        playCount: 0,
        averageRating: "0",
        ratingCount: 0
      },
      {
        id: "650e8400-e29b-41d4-a716-446655440008",
        title: "Digital Waves",
        artist: "Cyber Collective",
        duration: 340,
        genre: "Progressive House",
        audioUrl: "https://www.soundjay.com/misc/sounds/bell-ringing-05.wav",
        coverArtUrl: "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=400&h=400&fit=crop",
        accessType: "paid" as const,
        status: "pending" as const,
        playCount: 0,
        averageRating: "0",
        ratingCount: 0
      }
    ];

    await db.insert(tracks).values(pendingTracks).onConflictDoNothing();

    // Sample live stream
    const liveStreamData = {
      id: "750e8400-e29b-41d4-a716-446655440001",
      djName: "DJ Phoenix",
      title: "Friday Night Deep Sessions",
      description: "Deep house vibes to get your weekend started right",
      isLive: true,
      viewerCount: 847,
      startedAt: new Date(),
      streamUrl: "https://example.com/stream/1"
    };

    await db.insert(liveStreams).values(liveStreamData).onConflictDoNothing();

    console.log("✅ Database seeded successfully!");
    console.log(`- Added ${albumData.length} albums`);
    console.log(`- Added ${trackData.length} tracks`);
    console.log("- Added 1 live stream");

  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}