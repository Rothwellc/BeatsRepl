import {
  users,
  tracks,
  albums,
  ratings,
  playlists,
  playlistTracks,
  liveStreams,
  playHistory,
  type User,
  type UpsertUser,
  type Track,
  type InsertTrack,
  type Album,
  type InsertAlbum,
  type Rating,
  type InsertRating,
  type Playlist,
  type InsertPlaylist,
  type LiveStream,
  type InsertLiveStream,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, and, or, like, sql, gt } from "drizzle-orm";

export interface IStorage {
  // User operations - required for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserTier(userId: string, tier: string, expiryDate?: Date): Promise<User>;

  // Track operations
  getTracks(limit?: number, offset?: number): Promise<Track[]>;
  getTracksByGenre(genre: string, limit?: number): Promise<Track[]>;
  getFeaturedTracks(limit?: number): Promise<Track[]>;
  getTrendingTracks(limit?: number): Promise<Track[]>;
  getTrackById(id: string): Promise<Track | undefined>;
  createTrack(track: InsertTrack): Promise<Track>;
  updateTrack(id: string, updates: Partial<InsertTrack>): Promise<Track>;
  deleteTrack(id: string): Promise<void>;
  approveTrack(id: string): Promise<Track>;
  rejectTrack(id: string): Promise<Track>;
  incrementPlayCount(trackId: string): Promise<void>;

  // Rating operations
  rateTrack(userId: string, trackId: string, score: number): Promise<Rating>;
  getTrackRating(userId: string, trackId: string): Promise<Rating | undefined>;
  updateTrackAverageRating(trackId: string): Promise<void>;

  // Album operations
  getAlbums(limit?: number, offset?: number): Promise<Album[]>;
  getAlbumById(id: string): Promise<Album | undefined>;
  createAlbum(album: InsertAlbum): Promise<Album>;

  // Playlist operations
  getUserPlaylists(userId: string): Promise<Playlist[]>;
  createPlaylist(playlist: InsertPlaylist): Promise<Playlist>;

  // Live stream operations
  getCurrentLiveStream(): Promise<LiveStream | undefined>;
  createLiveStream(stream: InsertLiveStream): Promise<LiveStream>;
  updateLiveStream(id: string, updates: Partial<InsertLiveStream>): Promise<LiveStream>;

  // Analytics and user operations
  getPlayHistory(userId: string, limit?: number): Promise<any[]>;
  recordPlay(userId: string, trackId: string, duration: number): Promise<void>;
  getTopTracks(limit?: number): Promise<Track[]>;
  getGenreStats(): Promise<any[]>;
  
  // Additional user profile methods
  getUserPlayHistory(userId: string): Promise<any[]>;
  getUserLikedTracks(userId: string): Promise<Track[]>;
  getUserPurchases(userId: string): Promise<Track[]>;
  purchaseTrack(userId: string, trackId: string, price: number): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    // For demo purposes, make the first user an admin
    const isFirstUser = userData.id === 'demo-admin' || userData.email?.includes('admin');
    const userWithTier = {
      ...userData,
      tier: isFirstUser ? 'admin' : userData.tier || 'free'
    };

    const [user] = await db
      .insert(users)
      .values(userWithTier)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userWithTier,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserTier(userId: string, tier: string, expiryDate?: Date): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        tier,
        subscriptionExpiry: expiryDate,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    
    if (!user) {
      throw new Error("User not found");
    }
    
    return user;
  }

  async updateUserTier(userId: string, tier: string, expiryDate?: Date): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        tier,
        subscriptionExpiry: expiryDate,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Track operations
  async getTracks(limit = 50, offset = 0): Promise<Track[]> {
    return await db
      .select()
      .from(tracks)
      .where(eq(tracks.status, "approved"))
      .orderBy(desc(tracks.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getTracksByGenre(genre: string, limit = 20): Promise<Track[]> {
    return await db
      .select()
      .from(tracks)
      .where(and(eq(tracks.status, "approved"), eq(tracks.genre, genre)))
      .orderBy(desc(tracks.playCount))
      .limit(limit);
  }

  async getFeaturedTracks(limit = 12): Promise<Track[]> {
    return await db
      .select()
      .from(tracks)
      .where(
        and(
          eq(tracks.status, "approved"),
          gt(tracks.featuredUntil, new Date())
        )
      )
      .orderBy(desc(tracks.playCount))
      .limit(limit);
  }

  async getTrendingTracks(limit = 10): Promise<Track[]> {
    return await db
      .select()
      .from(tracks)
      .where(eq(tracks.status, "approved"))
      .orderBy(desc(tracks.playCount))
      .limit(limit);
  }

  async getTrackById(id: string): Promise<Track | undefined> {
    const [track] = await db.select().from(tracks).where(eq(tracks.id, id));
    return track;
  }

  async createTrack(track: InsertTrack): Promise<Track> {
    const [newTrack] = await db.insert(tracks).values(track).returning();
    return newTrack;
  }

  async updateTrack(id: string, updates: Partial<InsertTrack>): Promise<Track> {
    const [track] = await db
      .update(tracks)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(tracks.id, id))
      .returning();
    return track;
  }

  async deleteTrack(id: string): Promise<void> {
    await db.delete(tracks).where(eq(tracks.id, id));
  }

  async approveTrack(id: string): Promise<Track> {
    const [track] = await db
      .update(tracks)
      .set({ status: "approved", updatedAt: new Date() })
      .where(eq(tracks.id, id))
      .returning();
    return track;
  }

  async rejectTrack(id: string): Promise<Track> {
    const [track] = await db
      .update(tracks)
      .set({ status: "rejected", updatedAt: new Date() })
      .where(eq(tracks.id, id))
      .returning();
    return track;
  }

  async incrementPlayCount(trackId: string): Promise<void> {
    await db
      .update(tracks)
      .set({ playCount: sql`${tracks.playCount} + 1` })
      .where(eq(tracks.id, trackId));
  }

  // Rating operations
  async rateTrack(userId: string, trackId: string, score: number): Promise<Rating> {
    const [rating] = await db
      .insert(ratings)
      .values({ userId, trackId, score })
      .onConflictDoUpdate({
        target: [ratings.userId, ratings.trackId],
        set: { score },
      })
      .returning();

    // Update track average rating
    await this.updateTrackAverageRating(trackId);
    return rating;
  }

  async getTrackRating(userId: string, trackId: string): Promise<Rating | undefined> {
    const [rating] = await db
      .select()
      .from(ratings)
      .where(and(eq(ratings.userId, userId), eq(ratings.trackId, trackId)));
    return rating;
  }

  async updateTrackAverageRating(trackId: string): Promise<void> {
    const result = await db
      .select({
        avg: sql<number>`avg(${ratings.score})`,
        count: sql<number>`count(*)`,
      })
      .from(ratings)
      .where(eq(ratings.trackId, trackId));

    const { avg, count } = result[0];
    await db
      .update(tracks)
      .set({
        averageRating: avg ? avg.toString() : "0",
        ratingCount: count || 0,
      })
      .where(eq(tracks.id, trackId));
  }

  // Album operations
  async getAlbums(limit = 20, offset = 0): Promise<Album[]> {
    return await db
      .select()
      .from(albums)
      .orderBy(desc(albums.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getAlbumById(id: string): Promise<Album | undefined> {
    const [album] = await db.select().from(albums).where(eq(albums.id, id));
    return album;
  }

  async createAlbum(album: InsertAlbum): Promise<Album> {
    const [newAlbum] = await db.insert(albums).values(album).returning();
    return newAlbum;
  }

  // Playlist operations
  async getUserPlaylists(userId: string): Promise<Playlist[]> {
    return await db
      .select()
      .from(playlists)
      .where(eq(playlists.userId, userId))
      .orderBy(desc(playlists.createdAt));
  }

  async createPlaylist(playlist: InsertPlaylist): Promise<Playlist> {
    const [newPlaylist] = await db.insert(playlists).values(playlist).returning();
    return newPlaylist;
  }

  // Live stream operations
  async getCurrentLiveStream(): Promise<LiveStream | undefined> {
    const [stream] = await db
      .select()
      .from(liveStreams)
      .where(eq(liveStreams.isLive, true))
      .orderBy(desc(liveStreams.startedAt))
      .limit(1);
    return stream;
  }

  async createLiveStream(stream: InsertLiveStream): Promise<LiveStream> {
    const [newStream] = await db.insert(liveStreams).values(stream).returning();
    return newStream;
  }

  async updateLiveStream(id: string, updates: Partial<InsertLiveStream>): Promise<LiveStream> {
    const [stream] = await db
      .update(liveStreams)
      .set(updates)
      .where(eq(liveStreams.id, id))
      .returning();
    return stream;
  }

  // Analytics
  async getPlayHistory(userId: string, limit = 50): Promise<any[]> {
    return await db
      .select({
        track: tracks,
        playedAt: playHistory.playedAt,
        duration: playHistory.duration,
      })
      .from(playHistory)
      .innerJoin(tracks, eq(playHistory.trackId, tracks.id))
      .where(eq(playHistory.userId, userId))
      .orderBy(desc(playHistory.playedAt))
      .limit(limit);
  }

  async recordPlay(userId: string, trackId: string, duration: number): Promise<void> {
    await db.insert(playHistory).values({ userId, trackId, duration });
    await this.incrementPlayCount(trackId);
  }

  async getTopTracks(limit = 10): Promise<Track[]> {
    return await db
      .select()
      .from(tracks)
      .where(eq(tracks.status, "approved"))
      .orderBy(desc(tracks.playCount))
      .limit(limit);
  }

  async getGenreStats(): Promise<any[]> {
    return await db
      .select({
        genre: tracks.genre,
        count: sql<number>`count(*)`,
        totalPlays: sql<number>`sum(${tracks.playCount})`,
      })
      .from(tracks)
      .where(eq(tracks.status, "approved"))
      .groupBy(tracks.genre)
      .orderBy(desc(sql`sum(${tracks.playCount})`));
  }

  // User profile methods
  async getUserPlayHistory(userId: string): Promise<any[]> {
    return this.getPlayHistory(userId, 50);
  }

  async getUserLikedTracks(userId: string): Promise<Track[]> {
    const likedRatings = await db
      .select()
      .from(ratings)
      .innerJoin(tracks, eq(ratings.trackId, tracks.id))
      .where(and(eq(ratings.userId, userId), gt(ratings.score, 3)))
      .orderBy(desc(ratings.createdAt));
    
    return likedRatings.map(r => r.tracks);
  }

  async getUserPurchases(userId: string): Promise<Track[]> {
    // For demo purposes, return empty array
    // In real implementation, this would join with purchases table
    return [];
  }

  async purchaseTrack(userId: string, trackId: string, price: number): Promise<any> {
    // For demo purposes, return success
    // In real implementation, this would process payment and record purchase
    return {
      id: `purchase_${Date.now()}`,
      userId,
      trackId,
      price,
      purchasedAt: new Date()
    };
  }
}

export const storage = new DatabaseStorage();
