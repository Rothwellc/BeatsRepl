import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { seedDatabase } from "./seedData";
import { setupTestRoutes } from "./testRoutes";
import { insertTrackSchema, insertRatingSchema, insertPlaylistSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Test routes (no auth required)
  setupTestRoutes(app);

  // Auth middleware
  await setupAuth(app);

  // Seed database on startup (only in development)
  try {
    await seedDatabase();
  } catch (error) {
    console.log("Database already seeded or error occurred:", (error as Error).message);
  }

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Set user tier
  app.post('/api/auth/set-tier', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { tier } = req.body;

      if (!tier || !['subscriber', 'prepaid', 'contributor'].includes(tier)) {
        return res.status(400).json({ message: "Invalid tier" });
      }

      const updatedUser = await storage.updateUserTier(userId, tier);
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user tier:", error);
      res.status(500).json({ message: "Failed to update tier" });
    }
  });

  // Update user tier after signup
  app.post('/api/auth/set-tier', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { tier } = req.body;
      
      // Validate tier
      const validTiers = ['subscriber', 'prepaid', 'contributor'];
      if (!validTiers.includes(tier)) {
        return res.status(400).json({ message: "Invalid tier" });
      }
      
      await storage.updateUserTier(userId, tier);
      res.json({ message: "Tier updated successfully" });
    } catch (error) {
      console.error("Error updating user tier:", error);
      res.status(500).json({ message: "Failed to update tier" });
    }
  });

  // User playlist routes (Premium/Contributor only)
  app.get('/api/user/playlists', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || (user.tier !== 'prepaid' && user.tier !== 'contributor')) {
        return res.status(403).json({ message: "Premium subscription required" });
      }
      
      const playlists = await storage.getUserPlaylists(userId);
      res.json(playlists);
    } catch (error) {
      console.error("Error fetching user playlists:", error);
      res.status(500).json({ message: "Failed to fetch playlists" });
    }
  });

  app.post('/api/user/playlists', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || (user.tier !== 'prepaid' && user.tier !== 'contributor')) {
        return res.status(403).json({ message: "Premium subscription required" });
      }
      
      const { name, description } = req.body;
      const playlist = await storage.createPlaylist({ 
        userId, 
        name, 
        description: description || null,
        isPublic: false,
        coverArtUrl: null
      });
      res.json(playlist);
    } catch (error) {
      console.error("Error creating playlist:", error);
      res.status(500).json({ message: "Failed to create playlist" });
    }
  });

  // User history and purchases
  app.get('/api/user/history', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const history = await storage.getUserPlayHistory(userId);
      res.json(history);
    } catch (error) {
      console.error("Error fetching user history:", error);
      res.status(500).json({ message: "Failed to fetch history" });
    }
  });

  app.get('/api/user/liked', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const likedTracks = await storage.getUserLikedTracks(userId);
      res.json(likedTracks);
    } catch (error) {
      console.error("Error fetching liked tracks:", error);
      res.status(500).json({ message: "Failed to fetch liked tracks" });
    }
  });

  app.get('/api/user/purchases', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const purchases = await storage.getUserPurchases(userId);
      res.json(purchases);
    } catch (error) {
      console.error("Error fetching purchases:", error);
      res.status(500).json({ message: "Failed to fetch purchases" });
    }
  });

  // Track purchase endpoint
  app.post('/api/tracks/:trackId/purchase', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { trackId } = req.params;
      
      const track = await storage.getTrackById(trackId);
      if (!track) {
        return res.status(404).json({ message: "Track not found" });
      }
      
      const purchase = await storage.purchaseTrack(userId, trackId, 10); // Default price R10
      res.json(purchase);
    } catch (error) {
      console.error("Error purchasing track:", error);
      res.status(500).json({ message: "Failed to purchase track" });
    }
  });

  // Track routes
  app.get('/api/tracks', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      const genre = req.query.genre as string;

      let tracks;
      if (genre) {
        tracks = await storage.getTracksByGenre(genre, limit);
      } else {
        tracks = await storage.getTracks(limit, offset);
      }

      res.json(tracks);
    } catch (error) {
      console.error("Error fetching tracks:", error);
      res.status(500).json({ message: "Failed to fetch tracks" });
    }
  });

  app.get('/api/tracks/featured', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 12;
      const tracks = await storage.getFeaturedTracks(limit);
      res.json(tracks);
    } catch (error) {
      console.error("Error fetching featured tracks:", error);
      res.status(500).json({ message: "Failed to fetch featured tracks" });
    }
  });

  app.get('/api/tracks/trending', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const tracks = await storage.getTrendingTracks(limit);
      res.json(tracks);
    } catch (error) {
      console.error("Error fetching trending tracks:", error);
      res.status(500).json({ message: "Failed to fetch trending tracks" });
    }
  });

  app.get('/api/tracks/:id', async (req, res) => {
    try {
      const track = await storage.getTrackById(req.params.id);
      if (!track) {
        return res.status(404).json({ message: "Track not found" });
      }
      res.json(track);
    } catch (error) {
      console.error("Error fetching track:", error);
      res.status(500).json({ message: "Failed to fetch track" });
    }
  });

  app.post('/api/tracks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || (user.tier !== 'contributor' && user.tier !== 'admin')) {
        return res.status(403).json({ message: "Contributor access required" });
      }

      const trackData = insertTrackSchema.parse({
        ...req.body,
        contributorId: userId,
      });

      const track = await storage.createTrack(trackData);
      res.status(201).json(track);
    } catch (error) {
      console.error("Error creating track:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid track data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create track" });
    }
  });

  app.patch('/api/tracks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const track = await storage.getTrackById(req.params.id);

      if (!track) {
        return res.status(404).json({ message: "Track not found" });
      }

      if (user?.tier !== 'admin' && track.contributorId !== userId) {
        return res.status(403).json({ message: "Permission denied" });
      }

      const updates = insertTrackSchema.partial().parse(req.body);
      const updatedTrack = await storage.updateTrack(req.params.id, updates);
      res.json(updatedTrack);
    } catch (error) {
      console.error("Error updating track:", error);
      res.status(500).json({ message: "Failed to update track" });
    }
  });

  app.delete('/api/tracks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (user?.tier !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      await storage.deleteTrack(req.params.id);
      res.json({ message: "Track deleted successfully" });
    } catch (error) {
      console.error("Error deleting track:", error);
      res.status(500).json({ message: "Failed to delete track" });
    }
  });

  // Rating routes
  app.post('/api/tracks/:id/rate', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user || user.tier === 'free') {
        return res.status(403).json({ message: "Paid subscription required for rating" });
      }

      const { score } = insertRatingSchema.parse({
        userId,
        trackId: req.params.id,
        score: req.body.score,
      });

      const rating = await storage.rateTrack(userId, req.params.id, score);
      res.json(rating);
    } catch (error) {
      console.error("Error rating track:", error);
      res.status(500).json({ message: "Failed to rate track" });
    }
  });

  app.get('/api/tracks/:id/rating', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const rating = await storage.getTrackRating(userId, req.params.id);
      res.json(rating || null);
    } catch (error) {
      console.error("Error fetching rating:", error);
      res.status(500).json({ message: "Failed to fetch rating" });
    }
  });

  // Play tracking
  app.post('/api/tracks/:id/play', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const duration = parseInt(req.body.duration) || 0;
      
      await storage.recordPlay(userId, req.params.id, duration);
      res.json({ message: "Play recorded" });
    } catch (error) {
      console.error("Error recording play:", error);
      res.status(500).json({ message: "Failed to record play" });
    }
  });

  // Live stream routes
  app.get('/api/live-stream', async (req, res) => {
    try {
      const stream = await storage.getCurrentLiveStream();
      res.json(stream || null);
    } catch (error) {
      console.error("Error fetching live stream:", error);
      res.status(500).json({ message: "Failed to fetch live stream" });
    }
  });

  // Analytics routes
  app.get('/api/analytics/top-tracks', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const tracks = await storage.getTopTracks(limit);
      res.json(tracks);
    } catch (error) {
      console.error("Error fetching top tracks:", error);
      res.status(500).json({ message: "Failed to fetch top tracks" });
    }
  });

  app.get('/api/analytics/genres', async (req, res) => {
    try {
      const stats = await storage.getGenreStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching genre stats:", error);
      res.status(500).json({ message: "Failed to fetch genre stats" });
    }
  });

  // Admin routes
  app.get('/api/admin/tracks/pending', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (user?.tier !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      // Get pending tracks - simplified query for now
      const tracks = await storage.getTracks(100, 0);
      const pendingTracks = tracks.filter(track => track.status === 'pending');
      res.json(pendingTracks);
    } catch (error) {
      console.error("Error fetching pending tracks:", error);
      res.status(500).json({ message: "Failed to fetch pending tracks" });
    }
  });

  app.post('/api/admin/tracks/:id/approve', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (user?.tier !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const track = await storage.approveTrack(req.params.id);
      res.json(track);
    } catch (error) {
      console.error("Error approving track:", error);
      res.status(500).json({ message: "Failed to approve track" });
    }
  });

  app.post('/api/admin/tracks/:id/reject', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (user?.tier !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const track = await storage.rejectTrack(req.params.id);
      res.json(track);
    } catch (error) {
      console.error("Error rejecting track:", error);
      res.status(500).json({ message: "Failed to reject track" });
    }
  });

  app.post('/api/admin/users/:id/tier', isAuthenticated, async (req: any, res) => {
    try {
      const adminUserId = req.user.claims.sub;
      const adminUser = await storage.getUser(adminUserId);

      if (adminUser?.tier !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { tier, expiryDate } = req.body;
      const user = await storage.updateUserTier(req.params.id, tier, expiryDate ? new Date(expiryDate) : undefined);
      res.json(user);
    } catch (error) {
      console.error("Error updating user tier:", error);
      res.status(500).json({ message: "Failed to update user tier" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
