# Overview

Best Beats is a comprehensive house music streaming platform designed to deliver a superior experience to Spotify. The application features a sophisticated tier-based subscription system, real-time music playback with access restrictions, user authentication, playlist management, and music purchasing capabilities. Built as a full-stack web application with React frontend, Express backend, and PostgreSQL database, it's production-ready with complete tier-based monetization.

## Current Status (January 2025)
- ✅ Complete tier-based subscription system implemented
- ✅ PostgreSQL database connected and seeded with sample data
- ✅ Audio player with tier-based playback restrictions
- ✅ User authentication and tier upgrade flows
- ✅ Best Beats logo integration (white version)
- ✅ Playlist creation and music purchasing features
- ✅ Admin panel and contributor upload system
- ✅ Responsive design with professional UI/UX

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent design
- **Styling**: Tailwind CSS with custom CSS variables for theming, featuring a cool red gradient color scheme
- **Build Tool**: Vite for fast development and optimized production builds

## Backend Architecture
- **Framework**: Express.js with TypeScript for API server
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: Replit Auth integration with OpenID Connect for seamless user authentication
- **Session Management**: Express sessions with PostgreSQL session store for persistence
- **API Design**: RESTful API structure with proper error handling and logging middleware

## Database Schema Design
- **Users Table**: Supports tiered user system (free, subscriber, prepaid, contributor, admin) with subscription tracking
- **Tracks Table**: Comprehensive music metadata with approval workflow, play counts, and rating system
- **Albums Table**: Album organization with release date tracking
- **Ratings Table**: User rating system with composite keys for track-user relationships
- **Playlists System**: User-created playlists with many-to-many track relationships
- **Live Streams Table**: Real-time streaming session management with viewer tracking
- **Play History**: User listening behavior tracking for analytics and recommendations

## User Tier System
The application implements a comprehensive tier-based restriction system:

1. **Free User**: Cannot stream music, no preview access, shows upgrade prompts and restrictions
2. **Free Subscriber**: 30-second track previews only, social sharing enabled, email signup required
3. **Premium Subscriber (R25/month)**: Full unlimited streaming, playlist creation, music downloads, ad-free experience
4. **Contributor (R45/month)**: All premium features plus track upload rights, revenue earning, detailed analytics
5. **Admin**: Full platform management, user management, track approval workflow

Each tier has clearly defined capabilities and restrictions, with automatic enforcement through the audio player component and API endpoints.

## Audio Management
- **Tier-Based Audio Player**: Custom component with intelligent playback restrictions based on user subscription level
- **Preview System**: 30-second previews for free subscribers, full tracks for premium users, no access for free users
- **Fixed Bottom Player**: Persistent audio player that appears when tracks are selected from landing page
- **Restriction Enforcement**: Automatic tier validation with upgrade prompts and clear feature limitations
- **File Handling**: Support for MP3 format with sample tracks included for demonstration

## Security and Authentication
- **Authentication Provider**: Replit Auth with OIDC for secure user management
- **Session Security**: HTTP-only cookies with proper CSRF protection
- **Authorization**: Route-level protection based on user tiers and roles
- **Data Validation**: Zod schemas for runtime type checking and API validation

# External Dependencies

## Core Services
- **Database**: PostgreSQL database fully configured and connected with complete schema
- **Authentication**: Replit Auth service with tier-based user management and session persistence
- **Media Storage**: Sample audio files and Best Beats logo assets integrated
- **Tier Management**: Complete subscription handling with upgrade flows and feature restrictions

## Development Tools
- **TypeScript**: Static typing for both frontend and backend code
- **ESLint**: Code quality and consistency enforcement
- **Vite**: Frontend build tool with hot reload and optimized builds

## UI/UX Libraries
- **Radix UI**: Accessible component primitives for consistent user interface
- **Tailwind CSS**: Utility-first CSS framework for responsive design
- **Lucide Icons**: Consistent icon system throughout the application
- **React Hook Form**: Form handling with validation integration

## Third-Party Integrations
- **Social Sharing**: Platform integration for track sharing (subscriber tier and above)
- **Analytics**: User behavior tracking for play history and recommendations
- **Payment Processing**: Subscription management for paid tier users (implementation pending)
- **Live Streaming**: Real-time streaming infrastructure for DJ sets and performances