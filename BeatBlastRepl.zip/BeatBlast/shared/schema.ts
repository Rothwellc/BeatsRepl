import { sql } from "drizzle-orm";
import {
  index,
  jsonb,
  pgTable,
  text,
  varchar,
  timestamp,
  integer,
  decimal,
  boolean,
  uuid,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table - required for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - required for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  tier: varchar("tier").notNull().default("free"), // free, subscriber, prepaid, contributor, admin
  subscriptionExpiry: timestamp("subscription_expiry"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const tracks = pgTable("tracks", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title", { length: 255 }).notNull(),
  artist: varchar("artist", { length: 255 }).notNull(),
  genre: varchar("genre", { length: 100 }).notNull(),
  duration: integer("duration").notNull(), // in seconds
  audioUrl: text("audio_url").notNull(),
  coverArtUrl: text("cover_art_url"),
  contributorId: varchar("contributor_id").references(() => users.id),
  isPreview: boolean("is_preview").default(false),
  accessType: varchar("access_type").notNull().default("free"), // free, paid, preview
  status: varchar("status").notNull().default("pending"), // pending, approved, rejected
  playCount: integer("play_count").default(0),
  averageRating: decimal("average_rating", { precision: 3, scale: 2 }).default("0"),
  ratingCount: integer("rating_count").default(0),
  featuredUntil: timestamp("featured_until"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const albums = pgTable("albums", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 255 }).notNull(),
  artistId: varchar("artist_id").references(() => users.id),
  coverArtUrl: text("cover_art_url"),
  releaseDate: timestamp("release_date"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const albumTracks = pgTable("album_tracks", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  albumId: uuid("album_id").references(() => albums.id).notNull(),
  trackId: uuid("track_id").references(() => tracks.id).notNull(),
  position: integer("position").notNull(),
});

export const ratings = pgTable("ratings", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  trackId: uuid("track_id").references(() => tracks.id).notNull(),
  score: integer("score").notNull(), // 1-5 stars
  createdAt: timestamp("created_at").defaultNow(),
});

export const playlists = pgTable("playlists", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  isPublic: boolean("is_public").default(false),
  coverArtUrl: text("cover_art_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const playlistTracks = pgTable("playlist_tracks", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  playlistId: uuid("playlist_id").references(() => playlists.id).notNull(),
  trackId: uuid("track_id").references(() => tracks.id).notNull(),
  position: integer("position").notNull(),
  addedAt: timestamp("added_at").defaultNow(),
});

export const playHistory = pgTable("play_history", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  trackId: uuid("track_id").references(() => tracks.id).notNull(),
  playedAt: timestamp("played_at").defaultNow(),
  duration: integer("duration"), // how long they listened in seconds
});

export const liveStreams = pgTable("live_streams", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  djName: varchar("dj_name", { length: 255 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  streamUrl: text("stream_url"),
  isLive: boolean("is_live").default(false),
  viewerCount: integer("viewer_count").default(0),
  startedAt: timestamp("started_at"),
  endedAt: timestamp("ended_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const userRelations = relations(users, ({ many }) => ({
  tracks: many(tracks),
  ratings: many(ratings),
  playlists: many(playlists),
  playHistory: many(playHistory),
}));

export const trackRelations = relations(tracks, ({ one, many }) => ({
  contributor: one(users, {
    fields: [tracks.contributorId],
    references: [users.id],
  }),
  ratings: many(ratings),
  albumTracks: many(albumTracks),
  playlistTracks: many(playlistTracks),
  playHistory: many(playHistory),
}));

export const albumRelations = relations(albums, ({ one, many }) => ({
  artist: one(users, {
    fields: [albums.artistId],
    references: [users.id],
  }),
  albumTracks: many(albumTracks),
}));

export const ratingRelations = relations(ratings, ({ one }) => ({
  user: one(users, {
    fields: [ratings.userId],
    references: [users.id],
  }),
  track: one(tracks, {
    fields: [ratings.trackId],
    references: [tracks.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTrackSchema = createInsertSchema(tracks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  playCount: true,
  averageRating: true,
  ratingCount: true,
});

export const insertAlbumSchema = createInsertSchema(albums).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRatingSchema = createInsertSchema(ratings).omit({
  id: true,
  createdAt: true,
});

export const insertPlaylistSchema = createInsertSchema(playlists).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertLiveStreamSchema = createInsertSchema(liveStreams).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Track = typeof tracks.$inferSelect;
export type InsertTrack = z.infer<typeof insertTrackSchema>;
export type Album = typeof albums.$inferSelect;
export type InsertAlbum = z.infer<typeof insertAlbumSchema>;
export type Rating = typeof ratings.$inferSelect;
export type InsertRating = z.infer<typeof insertRatingSchema>;
export type Playlist = typeof playlists.$inferSelect;
export type InsertPlaylist = z.infer<typeof insertPlaylistSchema>;
export type LiveStream = typeof liveStreams.$inferSelect;
export type InsertLiveStream = z.infer<typeof insertLiveStreamSchema>;
