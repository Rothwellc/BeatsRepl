import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Lock, Crown, Star, Users, Music, Clock, Download, Upload, DollarSign } from "lucide-react";

interface TierRestrictionsProps {
  currentTier: string;
  feature: string;
  onUpgrade?: () => void;
}

const TIER_FEATURES = {
  free: {
    name: "Free User",
    icon: Users,
    color: "text-gray-400",
    bgColor: "bg-gray-600",
    features: {
      streaming: { allowed: false, description: "No streaming access" },
      previews: { allowed: false, description: "No previews available" },
      playlists: { allowed: false, description: "Cannot create playlists" },
      downloads: { allowed: false, description: "No download access" },
      uploads: { allowed: false, description: "Cannot upload tracks" },
      socialSharing: { allowed: false, description: "No social features" },
      ads: { allowed: true, description: "Contains advertisements" }
    }
  },
  subscriber: {
    name: "Free Subscriber",
    icon: Users,
    color: "text-green-400",
    bgColor: "bg-green-600",
    features: {
      streaming: { allowed: false, description: "No full track streaming" },
      previews: { allowed: true, description: "30-second track previews" },
      playlists: { allowed: false, description: "Cannot create playlists" },
      downloads: { allowed: false, description: "No download access" },
      uploads: { allowed: false, description: "Cannot upload tracks" },
      socialSharing: { allowed: true, description: "Can share tracks socially" },
      ads: { allowed: true, description: "Contains advertisements" }
    }
  },
  prepaid: {
    name: "Premium",
    icon: Star,
    color: "text-red-400",
    bgColor: "bg-red-600",
    features: {
      streaming: { allowed: true, description: "Unlimited full track streaming" },
      previews: { allowed: true, description: "Full track access + previews" },
      playlists: { allowed: true, description: "Create unlimited playlists" },
      downloads: { allowed: true, description: "Download tracks for offline" },
      uploads: { allowed: false, description: "Cannot upload tracks" },
      socialSharing: { allowed: true, description: "Full social sharing features" },
      ads: { allowed: false, description: "Ad-free experience" }
    }
  },
  contributor: {
    name: "Contributor",
    icon: Crown,
    color: "text-purple-400",
    bgColor: "bg-purple-600",
    features: {
      streaming: { allowed: true, description: "Unlimited streaming access" },
      previews: { allowed: true, description: "Full access to all content" },
      playlists: { allowed: true, description: "Unlimited playlist creation" },
      downloads: { allowed: true, description: "Download any track" },
      uploads: { allowed: true, description: "Upload unlimited tracks" },
      socialSharing: { allowed: true, description: "Full social features + analytics" },
      ads: { allowed: false, description: "Completely ad-free" },
      revenue: { allowed: true, description: "Earn revenue from uploads" },
      analytics: { allowed: true, description: "Detailed track analytics" }
    }
  }
};

export function TierRestrictionModal({ currentTier, feature, onUpgrade }: TierRestrictionsProps) {
  const tier = TIER_FEATURES[currentTier as keyof typeof TIER_FEATURES] || TIER_FEATURES.free;
  const TierIcon = tier.icon;
  
  const getRequiredTier = (feature: string) => {
    switch (feature) {
      case 'streaming': return 'prepaid';
      case 'playlists': return 'prepaid';
      case 'downloads': return 'prepaid';
      case 'uploads': return 'contributor';
      case 'revenue': return 'contributor';
      case 'analytics': return 'contributor';
      default: return 'subscriber';
    }
  };

  const requiredTier = getRequiredTier(feature);
  const requiredTierInfo = TIER_FEATURES[requiredTier as keyof typeof TIER_FEATURES];

  return (
    <Card className="bg-gray-800 border-gray-700 max-w-md mx-auto">
      <CardContent className="p-6 text-center">
        <div className="mb-4">
          <div className={`w-16 h-16 ${tier.bgColor} rounded-full flex items-center justify-center mx-auto mb-3`}>
            <Lock className="h-8 w-8 text-white" />
          </div>
          <h3 className="text-xl font-bold mb-2">Feature Restricted</h3>
          <p className="text-gray-400 mb-4">
            This feature requires {requiredTierInfo.name} or higher
          </p>
        </div>

        <div className="space-y-3 mb-6">
          <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
            <span className="text-sm">Your Current Tier</span>
            <Badge className={`${tier.bgColor} text-white`}>
              <TierIcon className="w-3 h-3 mr-1" />
              {tier.name}
            </Badge>
          </div>
          <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
            <span className="text-sm">Required Tier</span>
            <Badge className={`${requiredTierInfo.bgColor} text-white`}>
              <requiredTierInfo.icon className="w-3 h-3 mr-1" />
              {requiredTierInfo.name}
            </Badge>
          </div>
        </div>

        <Button 
          onClick={onUpgrade || (() => window.location.href = "/signup")}
          className="w-full cool-red-gradient hover:bg-red-700"
        >
          Upgrade Now
        </Button>
      </CardContent>
    </Card>
  );
}

export function TierFeaturesDisplay({ tier }: { tier: string }) {
  const tierInfo = TIER_FEATURES[tier as keyof typeof TIER_FEATURES] || TIER_FEATURES.free;
  const TierIcon = tierInfo.icon;

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardContent className="p-6">
        <div className="flex items-center mb-4">
          <div className={`w-12 h-12 ${tierInfo.bgColor} rounded-full flex items-center justify-center mr-3`}>
            <TierIcon className="h-6 w-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-bold">{tierInfo.name}</h3>
            <p className="text-sm text-gray-400">Your current plan</p>
          </div>
        </div>

        <div className="space-y-3">
          {Object.entries(tierInfo.features).map(([key, feature]) => (
            <div key={key} className="flex items-center justify-between">
              <div className="flex items-center">
                <div className={`w-3 h-3 rounded-full mr-3 ${feature.allowed ? 'bg-green-400' : 'bg-red-400'}`}></div>
                <span className="text-sm">{feature.description}</span>
              </div>
              {!feature.allowed && (
                <Lock className="h-4 w-4 text-gray-400" />
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export function checkTierAccess(currentTier: string, feature: string): boolean {
  const tier = TIER_FEATURES[currentTier as keyof typeof TIER_FEATURES] || TIER_FEATURES.free;
  return tier.features[feature as keyof typeof tier.features]?.allowed || false;
}

export { TIER_FEATURES };