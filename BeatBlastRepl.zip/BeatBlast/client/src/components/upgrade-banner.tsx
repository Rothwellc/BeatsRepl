import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Crown, Music, X } from "lucide-react";
import { useState } from "react";

interface UpgradeBannerProps {
  currentTier: string;
  onDismiss?: () => void;
}

export default function UpgradeBanner({ currentTier, onDismiss }: UpgradeBannerProps) {
  const [isDismissed, setIsDismissed] = useState(false);

  const handleDismiss = () => {
    setIsDismissed(true);
    onDismiss?.();
  };

  if (isDismissed || currentTier === 'contributor') {
    return null; // Don't show banner for highest tier or if dismissed
  }

  const upgrades = {
    subscriber: {
      title: "Upgrade to Premium",
      description: "Unlock unlimited streaming, playlists, and ad-free experience",
      price: "R25/month",
      features: ["Unlimited full tracks", "Create playlists", "Background playback", "High-quality audio"],
      icon: Star,
      gradient: "from-red-600 to-red-800",
      ctaText: "Go Premium"
    },
    prepaid: {
      title: "Become a Contributor",
      description: "Upload your own tracks and earn revenue from your music",
      price: "R45/month", 
      features: ["Upload unlimited tracks", "Revenue sharing", "Artist analytics", "Priority support"],
      icon: Crown,
      gradient: "from-purple-600 to-purple-800",
      ctaText: "Become Contributor"
    }
  };

  const upgrade = upgrades[currentTier as keyof typeof upgrades];
  
  if (!upgrade) return null;

  const IconComponent = upgrade.icon;

  return (
    <Card className="bg-gradient-to-r from-gray-800 to-gray-900 border-gray-700 mb-6 relative overflow-hidden">
      <div className={`absolute inset-0 bg-gradient-to-r ${upgrade.gradient} opacity-10`}></div>
      <CardContent className="p-6 relative">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${upgrade.gradient} flex items-center justify-center`}>
              <IconComponent className="h-6 w-6 text-white" />
            </div>
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-1">
                <h3 className="text-lg font-semibold text-white">{upgrade.title}</h3>
                <Badge className={`bg-gradient-to-r ${upgrade.gradient} text-white border-none`}>
                  {upgrade.price}
                </Badge>
              </div>
              <p className="text-gray-300 text-sm mb-2">{upgrade.description}</p>
              <div className="flex flex-wrap gap-2">
                {upgrade.features.slice(0, 2).map((feature, index) => (
                  <Badge key={index} variant="outline" className="text-xs border-gray-600 text-gray-300">
                    {feature}
                  </Badge>
                ))}
                {upgrade.features.length > 2 && (
                  <Badge variant="outline" className="text-xs border-gray-600 text-gray-300">
                    +{upgrade.features.length - 2} more
                  </Badge>
                )}
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button 
              onClick={() => window.location.href = "/signup"}
              className={`bg-gradient-to-r ${upgrade.gradient} hover:opacity-90 text-white font-semibold`}
            >
              <Music className="mr-2 h-4 w-4" />
              {upgrade.ctaText}
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleDismiss}
              className="text-gray-400 hover:text-white p-2"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}