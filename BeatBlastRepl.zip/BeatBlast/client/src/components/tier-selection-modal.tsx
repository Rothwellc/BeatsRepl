import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Check, X, Users, Star, Crown, Music, Download, Upload, DollarSign, Heart, Share2, Zap } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface TierSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTierSelected: (tier: string) => void;
}

const TIER_OPTIONS = [
  {
    id: "subscriber",
    name: "Free Subscriber",
    price: "Free",
    description: "Perfect for casual listeners",
    icon: Users,
    color: "border-green-600 bg-green-50/5",
    buttonColor: "bg-green-600 hover:bg-green-700",
    features: [
      { text: "30-second track previews", included: true },
      { text: "Social sharing features", included: true },
      { text: "Email notifications", included: true },
      { text: "Basic music discovery", included: true },
      { text: "Full track streaming", included: false },
      { text: "Playlist creation", included: false },
      { text: "Download for offline", included: false },
      { text: "Ad-free experience", included: false },
    ],
    popular: false,
  },
  {
    id: "prepaid",
    name: "Premium",
    price: "R25/month",
    description: "Unlimited music streaming",
    icon: Star,
    color: "border-red-600 bg-red-50/5",
    buttonColor: "cool-red-gradient",
    features: [
      { text: "Unlimited full track streaming", included: true },
      { text: "Create unlimited playlists", included: true },
      { text: "Download tracks for offline", included: true },
      { text: "Ad-free listening experience", included: true },
      { text: "High-quality audio streaming", included: true },
      { text: "Social sharing & discovery", included: true },
      { text: "Priority customer support", included: true },
      { text: "Upload your own tracks", included: false },
    ],
    popular: true,
  },
  {
    id: "contributor",
    name: "Contributor Pro",
    price: "R45/month",
    description: "For artists and creators",
    icon: Crown,
    color: "border-purple-600 bg-purple-50/5",
    buttonColor: "bg-purple-600 hover:bg-purple-700",
    features: [
      { text: "All Premium features included", included: true },
      { text: "Upload unlimited tracks", included: true },
      { text: "Earn revenue from your music", included: true },
      { text: "Detailed analytics dashboard", included: true },
      { text: "Priority track approval", included: true },
      { text: "Featured artist promotions", included: true },
      { text: "Direct fan engagement tools", included: true },
      { text: "Early access to new features", included: true },
    ],
    popular: false,
  },
];

export default function TierSelectionModal({ isOpen, onClose, onTierSelected }: TierSelectionModalProps) {
  const [selectedTier, setSelectedTier] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const selectTierMutation = useMutation({
    mutationFn: async (tier: string) => {
      const response = await apiRequest("POST", "/api/auth/set-tier", { tier });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success!",
        description: `Welcome to Best Beats ${selectedTier === 'subscriber' ? 'Free' : selectedTier === 'prepaid' ? 'Premium' : 'Contributor Pro'}!`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      onTierSelected(selectedTier);
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Selection Failed",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    },
  });

  const handleTierSelect = async (tierId: string) => {
    if (tierId === 'prepaid' || tierId === 'contributor') {
      // For paid tiers, redirect to payment processing
      window.location.href = `/signup?tier=${tierId}`;
      return;
    }

    setSelectedTier(tierId);
    setIsProcessing(true);
    
    try {
      await selectTierMutation.mutateAsync(tierId);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl bg-gray-900 border-gray-700 text-white">
        <DialogHeader className="text-center">
          <DialogTitle className="text-3xl font-bold mb-2">
            Choose Your <span className="cool-red-text-gradient">Best Beats</span> Experience
          </DialogTitle>
          <p className="text-gray-400 text-lg">
            Select the perfect plan to match your music listening needs
          </p>
        </DialogHeader>

        <div className="grid md:grid-cols-3 gap-6 py-6">
          {TIER_OPTIONS.map((tier) => {
            const TierIcon = tier.icon;
            
            return (
              <Card 
                key={tier.id} 
                className={`relative bg-gray-800 ${tier.color} border-2 transition-all duration-200 hover:scale-105 ${
                  tier.popular ? 'ring-2 ring-red-500 ring-opacity-50' : ''
                }`}
              >
                {tier.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-red-600 text-white px-4 py-1">
                      <Zap className="w-3 h-3 mr-1" />
                      Most Popular
                    </Badge>
                  </div>
                )}

                <CardHeader className="text-center pb-4">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
                    tier.id === 'subscriber' ? 'bg-green-600' : 
                    tier.id === 'prepaid' ? 'bg-red-600' : 'bg-purple-600'
                  }`}>
                    <TierIcon className="h-8 w-8 text-white" />
                  </div>
                  
                  <CardTitle className="text-xl font-bold">{tier.name}</CardTitle>
                  <p className="text-3xl font-bold mt-2">
                    {tier.price}
                  </p>
                  <p className="text-gray-400 text-sm">{tier.description}</p>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    {tier.features.map((feature, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <div className={`w-5 h-5 rounded-full flex items-center justify-center ${
                          feature.included ? 'bg-green-600' : 'bg-gray-600'
                        }`}>
                          {feature.included ? (
                            <Check className="h-3 w-3 text-white" />
                          ) : (
                            <X className="h-3 w-3 text-gray-400" />
                          )}
                        </div>
                        <span className={`text-sm ${feature.included ? 'text-white' : 'text-gray-500'}`}>
                          {feature.text}
                        </span>
                      </div>
                    ))}
                  </div>

                  <Button
                    onClick={() => handleTierSelect(tier.id)}
                    disabled={isProcessing}
                    className={`w-full mt-6 text-white font-semibold ${tier.buttonColor} ${
                      tier.id === 'prepaid' ? 'hover:bg-red-700' : ''
                    }`}
                  >
                    {isProcessing && selectedTier === tier.id ? (
                      "Processing..."
                    ) : tier.id === 'subscriber' ? (
                      "Start Free"
                    ) : (
                      `Choose ${tier.name}`
                    )}
                  </Button>

                  {tier.id !== 'subscriber' && (
                    <p className="text-xs text-gray-500 text-center mt-2">
                      Cancel anytime • No long-term commitment
                    </p>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="text-center pt-4 border-t border-gray-700">
          <p className="text-sm text-gray-400 mb-4">
            All plans include access to our growing library of house music tracks
          </p>
          <div className="flex justify-center space-x-6 text-xs text-gray-500">
            <div className="flex items-center space-x-1">
              <Music className="h-3 w-3" />
              <span>High-Quality Audio</span>
            </div>
            <div className="flex items-center space-x-1">
              <Heart className="h-3 w-3" />
              <span>Curated Content</span>
            </div>
            <div className="flex items-center space-x-1">
              <Share2 className="h-3 w-3" />
              <span>Social Features</span>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}