import { useState } from "react";
import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

interface StarRatingProps {
  rating: number; // User's rating (0-5)
  averageRating: number; // Average rating for display
  ratingCount: number; // Total number of ratings
  onRate: (rating: number) => void;
  disabled?: boolean;
}

export default function StarRating({ 
  rating, 
  averageRating, 
  ratingCount, 
  onRate, 
  disabled = false 
}: StarRatingProps) {
  const [hoveredRating, setHoveredRating] = useState(0);

  const handleStarClick = (starRating: number) => {
    if (!disabled) {
      onRate(starRating);
    }
  };

  const handleStarHover = (starRating: number) => {
    if (!disabled) {
      setHoveredRating(starRating);
    }
  };

  const handleMouseLeave = () => {
    setHoveredRating(0);
  };

  const getStarFill = (starIndex: number) => {
    const currentRating = hoveredRating || rating;
    return starIndex <= currentRating;
  };

  return (
    <div className="space-y-1">
      {/* Interactive stars for rating */}
      <div 
        className="flex items-center space-x-1"
        onMouseLeave={handleMouseLeave}
      >
        {[1, 2, 3, 4, 5].map((starIndex) => (
          <button
            key={starIndex}
            type="button"
            className={cn(
              "transition-colors",
              disabled ? "cursor-default" : "cursor-pointer hover:scale-110"
            )}
            onClick={() => handleStarClick(starIndex)}
            onMouseEnter={() => handleStarHover(starIndex)}
            disabled={disabled}
          >
            <Star
              className={cn(
                "h-4 w-4 transition-colors",
                getStarFill(starIndex)
                  ? "fill-yellow-400 text-yellow-400"
                  : "text-gray-400"
              )}
            />
          </button>
        ))}
      </div>

      {/* Average rating display */}
      <div className="flex items-center space-x-2 text-xs text-gray-400">
        <div className="flex items-center space-x-1">
          {[1, 2, 3, 4, 5].map((starIndex) => (
            <Star
              key={`avg-${starIndex}`}
              className={cn(
                "h-3 w-3",
                starIndex <= Math.round(averageRating)
                  ? "fill-yellow-400 text-yellow-400"
                  : "text-gray-600"
              )}
            />
          ))}
        </div>
        <span>
          {averageRating.toFixed(1)} ({ratingCount} {ratingCount === 1 ? 'rating' : 'ratings'})
        </span>
      </div>
    </div>
  );
}
