import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CloudUpload, X } from "lucide-react";

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadSuccess: () => void;
}

export default function UploadModal({ isOpen, onClose, onUploadSuccess }: UploadModalProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    title: "",
    artist: "",
    genre: "",
    accessType: "free",
    audioUrl: "https://example.com/sample-track.mp3", // Mock URL for demo
    coverArtUrl: "",
    duration: 240, // 4 minutes default
  });
  const [termsAccepted, setTermsAccepted] = useState(false);

  const uploadMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      await apiRequest("POST", "/api/tracks", data);
    },
    onSuccess: () => {
      onUploadSuccess();
      setFormData({
        title: "",
        artist: "",
        genre: "",
        accessType: "free",
        audioUrl: "https://example.com/sample-track.mp3",
        coverArtUrl: "",
        duration: 240,
      });
      setTermsAccepted(false);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Upload failed",
        description: "Failed to upload track. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!termsAccepted) {
      toast({
        title: "Terms required",
        description: "Please accept the terms and conditions.",
        variant: "destructive",
      });
      return;
    }

    if (!formData.title || !formData.artist || !formData.genre) {
      toast({
        title: "Missing fields",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    uploadMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-800 border-gray-700 max-w-2xl">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-2xl font-bold text-white">Upload New Track</DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-gray-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* File Upload Mockup */}
          <div>
            <Label className="text-sm font-medium text-white">Audio File (MP3, max 320kbps)</Label>
            <div className="border-2 border-dashed border-gray-600 rounded-lg p-8 text-center hover:border-red-400 transition-colors mt-2">
              <CloudUpload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-400">Drag & drop your MP3 file here or click to browse</p>
              <p className="text-xs text-gray-500 mt-2">Demo: Using sample audio URL</p>
            </div>
          </div>

          {/* Track Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="title" className="text-sm font-medium text-white">Track Title *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => handleInputChange("title", e.target.value)}
                placeholder="Enter track title"
                className="bg-gray-700 border-gray-600 text-white mt-2"
                required
              />
            </div>
            <div>
              <Label htmlFor="artist" className="text-sm font-medium text-white">Artist Name *</Label>
              <Input
                id="artist"
                value={formData.artist}
                onChange={(e) => handleInputChange("artist", e.target.value)}
                placeholder="Enter artist name"
                className="bg-gray-700 border-gray-600 text-white mt-2"
                required
              />
            </div>
          </div>

          {/* Cover Art Upload Mockup */}
          <div>
            <Label className="text-sm font-medium text-white">Cover Art</Label>
            <div className="border-2 border-dashed border-gray-600 rounded-lg p-6 text-center hover:border-red-400 transition-colors mt-2">
              <div className="h-8 w-8 mx-auto mb-2 text-gray-400">🎨</div>
              <p className="text-gray-400 text-sm">Upload album artwork (JPG/PNG, min 400x400px)</p>
              <Input
                value={formData.coverArtUrl}
                onChange={(e) => handleInputChange("coverArtUrl", e.target.value)}
                placeholder="Or paste image URL"
                className="bg-gray-700 border-gray-600 text-white mt-2"
              />
            </div>
          </div>

          {/* Genre and Access Type */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label className="text-sm font-medium text-white">Genre *</Label>
              <Select value={formData.genre} onValueChange={(value) => handleInputChange("genre", value)}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white mt-2">
                  <SelectValue placeholder="Select genre" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600">
                  <SelectItem value="deep-house">Deep House</SelectItem>
                  <SelectItem value="tech-house">Tech House</SelectItem>
                  <SelectItem value="progressive">Progressive House</SelectItem>
                  <SelectItem value="minimal">Minimal Techno</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-medium text-white">Access Type</Label>
              <Select value={formData.accessType} onValueChange={(value) => handleInputChange("accessType", value)}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600">
                  <SelectItem value="free">Free</SelectItem>
                  <SelectItem value="paid">Paid Only</SelectItem>
                  <SelectItem value="preview">Preview Available</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Duration */}
          <div>
            <Label htmlFor="duration" className="text-sm font-medium text-white">Duration (seconds)</Label>
            <Input
              id="duration"
              type="number"
              value={formData.duration}
              onChange={(e) => handleInputChange("duration", parseInt(e.target.value))}
              placeholder="Track duration in seconds"
              className="bg-gray-700 border-gray-600 text-white mt-2"
              min="1"
            />
          </div>

          {/* Terms and Conditions */}
          <div className="flex items-center space-x-3">
            <Checkbox
              id="terms"
              checked={termsAccepted}
              onCheckedChange={(checked) => setTermsAccepted(checked as boolean)}
              className="border-gray-600"
            />
            <Label htmlFor="terms" className="text-sm text-gray-300">
              I agree to the{" "}
              <a href="#" className="text-red-400 hover:text-red-300">
                Terms & Conditions
              </a>{" "}
              and confirm I own the rights to this content
            </Label>
          </div>

          {/* Submit Buttons */}
          <div className="flex justify-end space-x-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={uploadMutation.isPending || !termsAccepted}
              className="cool-red-gradient hover:bg-red-700 font-semibold"
            >
              {uploadMutation.isPending ? "Uploading..." : "Upload Track"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
