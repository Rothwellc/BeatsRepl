import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import StarRating from "@/components/ui/star-rating";
import { Play, Music, Lock } from "lucide-react";
import type { Track, UserTier, Rating } from "@/types/music";

interface TrackCardProps {
  track: Track;
  userTier: UserTier;
  onPlay: () => void;
}

export default function TrackCard({ track, userTier, onPlay }: TrackCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isHovered, setIsHovered] = useState(false);

  const { data: userRating } = useQuery<Rating | null>({
    queryKey: ["/api/tracks", track.id, "rating"],
    retry: false,
    enabled: userTier !== 'free',
  });

  const rateMutation = useMutation({
    mutationFn: async (score: number) => {
      await apiRequest("POST", `/api/tracks/${track.id}/rate`, { score });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tracks", track.id, "rating"] });
      toast({
        title: "Rating submitted",
        description: "Thank you for rating this track!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to submit rating.",
        variant: "destructive",
      });
    },
  });

  const handlePlay = () => {
    if (track.accessType === 'paid' && userTier === 'free') {
      toast({
        title: "Premium Required",
        description: "This track requires a premium subscription.",
        variant: "destructive",
      });
      return;
    }
    onPlay();
  };

  const handleRating = (score: number) => {
    if (userTier === 'free') {
      toast({
        title: "Premium Required",
        description: "Rating tracks requires a premium subscription.",
        variant: "destructive",
      });
      return;
    }
    rateMutation.mutate(score);
  };

  const isRestricted = track.accessType === 'paid' && userTier === 'free';

  return (
    <Card 
      className="music-card bg-gray-800 border-gray-700 overflow-hidden relative group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="aspect-square bg-gray-700 relative">
        {track.coverArtUrl ? (
          <img 
            src={track.coverArtUrl} 
            alt={track.title}
            className="w-full h-full object-cover" 
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center">
            <Music className="h-8 w-8 text-white" />
          </div>
        )}
        
        {/* Tier Restriction Overlay */}
        {isRestricted && (
          <div className={`absolute inset-0 tier-overlay bg-black/60 flex items-center justify-center transition-opacity ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
            <div className="text-center">
              <Lock className="h-6 w-6 mb-2 text-red-400 mx-auto" />
              <p className="text-sm font-medium">Premium Only</p>
            </div>
          </div>
        )}
        
        {/* Play Button Overlay */}
        {!isRestricted && (
          <div className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
            <Button 
              onClick={handlePlay}
              size="sm" 
              className="w-12 h-12 rounded-full cool-red-gradient hover:bg-red-700"
            >
              <Play className="h-4 w-4 text-white ml-0.5" />
            </Button>
          </div>
        )}

        {/* Premium/Preview Badge */}
        {track.accessType !== 'free' && (
          <div className="absolute top-2 right-2">
            <Badge 
              variant={track.accessType === 'paid' ? 'default' : 'secondary'}
              className={`text-xs ${track.accessType === 'paid' ? 'bg-yellow-600' : 'bg-blue-600'}`}
            >
              {track.accessType === 'paid' ? 'Premium' : 'Preview'}
            </Badge>
          </div>
        )}
      </div>
      
      <CardContent className="p-3">
        <h3 className="font-semibold text-sm truncate">{track.title}</h3>
        <p className="text-gray-400 text-xs truncate">{track.artist}</p>
        
        {/* Star Rating for Paid Users */}
        {userTier !== 'free' && (
          <div className="mt-2">
            <StarRating
              rating={userRating?.score || 0}
              averageRating={parseFloat(track.averageRating)}
              ratingCount={track.ratingCount}
              onRate={handleRating}
              disabled={rateMutation.isPending}
            />
          </div>
        )}

        {/* Genre Badge */}
        <div className="mt-2">
          <Badge variant="outline" className="text-xs border-gray-600 text-gray-400">
            {track.genre}
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}
