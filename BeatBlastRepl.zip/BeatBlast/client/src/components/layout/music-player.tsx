import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Volume2, 
  Share,
  Music 
} from "lucide-react";
import type { Track, UserTier } from "@/types/music";

interface MusicPlayerProps {
  track: Track;
  isPlaying: boolean;
  userTier: UserTier;
  onPlayPause: () => void;
}

export default function MusicPlayer({ track, isPlaying, userTier, onPlayPause }: MusicPlayerProps) {
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(50);
  const [currentTime, setCurrentTime] = useState(0);

  // Simulate playback progress
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          const newTime = prev + 1;
          const progressPercent = (newTime / track.duration) * 100;
          setProgress(progressPercent);
          
          // Auto-pause for free users after 30 seconds (preview mode)
          if (userTier === 'free' && newTime >= 30) {
            onPlayPause();
            return 30;
          }
          
          // Loop for demo purposes
          if (newTime >= track.duration) {
            return 0;
          }
          
          return newTime;
        });
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isPlaying, track.duration, userTier, onPlayPause]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleProgressChange = (value: number[]) => {
    const newTime = (value[0] / 100) * track.duration;
    setCurrentTime(newTime);
    setProgress(value[0]);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-black/95 backdrop-blur-sm border-t border-gray-800 p-4 z-40">
      <div className="max-w-7xl mx-auto">
        {/* Progress Bar */}
        <div className="mb-4">
          <Progress value={progress} className="w-full h-1 bg-gray-600" />
        </div>

        <div className="flex items-center justify-between">
          {/* Track Info */}
          <div className="flex items-center space-x-4 flex-1 min-w-0">
            <div className="w-12 h-12 rounded-lg bg-gray-600 flex items-center justify-center overflow-hidden flex-shrink-0">
              {track.coverArtUrl ? (
                <img 
                  src={track.coverArtUrl} 
                  alt={track.title}
                  className="w-full h-full object-cover" 
                />
              ) : (
                <Music className="h-6 w-6 text-gray-400" />
              )}
            </div>
            <div className="hidden sm:block min-w-0">
              <h4 className="font-semibold text-sm truncate">{track.title}</h4>
              <p className="text-gray-400 text-xs truncate">{track.artist}</p>
            </div>
          </div>

          {/* Player Controls */}
          <div className="flex items-center space-x-4 flex-1 justify-center">
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
              <SkipBack className="h-4 w-4" />
            </Button>
            
            <Button 
              onClick={onPlayPause}
              size="sm" 
              className="w-10 h-10 rounded-full cool-red-gradient hover:bg-red-700"
            >
              {isPlaying ? (
                <Pause className="h-4 w-4 text-white" />
              ) : (
                <Play className="h-4 w-4 text-white ml-0.5" />
              )}
            </Button>
            
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
              <SkipForward className="h-4 w-4" />
            </Button>

            {/* Time Display */}
            <div className="hidden md:flex items-center space-x-2 text-xs text-gray-400">
              <span>{formatTime(currentTime)}</span>
              <span>/</span>
              <span>{formatTime(track.duration)}</span>
            </div>
          </div>

          {/* Right Controls */}
          <div className="flex items-center space-x-4 flex-1 justify-end">
            {/* Volume Control - Only for paid users */}
            {userTier !== 'free' && (
              <div className="hidden md:flex items-center space-x-2">
                <Volume2 className="h-4 w-4 text-gray-400" />
                <Slider
                  value={[volume]}
                  onValueChange={(value) => setVolume(value[0])}
                  max={100}
                  step={1}
                  className="w-20"
                />
              </div>
            )}
            
            {/* Tier restriction notice for free users */}
            {userTier === 'free' && (
              <div className="text-xs text-red-400 hidden sm:block">
                Preview Only • Upgrade for Full Track
              </div>
            )}
            
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
              <Share className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
