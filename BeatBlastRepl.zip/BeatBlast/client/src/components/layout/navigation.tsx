import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { User, LogOut, Settings, Shield } from "lucide-react";
import type { User as UserType } from "@/types/music";

interface NavigationProps {
  user: UserType;
}

export default function Navigation({ user }: NavigationProps) {
  const getTierBadge = (tier: string) => {
    switch (tier) {
      case 'admin':
        return <Badge variant="default" className="bg-yellow-600 text-xs">ADMIN</Badge>;
      case 'contributor':
        return <Badge variant="default" className="bg-purple-600 text-xs">CONTRIBUTOR</Badge>;
      case 'prepaid':
        return <Badge variant="default" className="bg-blue-600 text-xs">PREPAID</Badge>;
      case 'subscriber':
        return <Badge variant="default" className="bg-green-600 text-xs">PREMIUM</Badge>;
      default:
        return <Badge variant="destructive" className="text-xs">FREE</Badge>;
    }
  };

  const getUpgradeButton = () => {
    if (user.tier === 'free') {
      return (
        <Button className="cool-red-gradient hover:bg-red-700 text-white">
          Upgrade to Pro
        </Button>
      );
    }
    return null;
  };

  return (
    <nav className="bg-black/90 backdrop-blur-sm border-b border-gray-800 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/">
              <div className="text-2xl font-bold cool-red-gradient bg-clip-text text-transparent cursor-pointer">
                Best Beats
              </div>
            </Link>
          </div>

          {/* Navigation Links */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <Link href="/">
                <a className="text-white hover:text-red-400 px-3 py-2 rounded-md text-sm font-medium">
                  Home
                </a>
              </Link>
              <Link href="/browse">
                <a className="text-gray-300 hover:text-red-400 px-3 py-2 rounded-md text-sm font-medium">
                  Browse
                </a>
              </Link>
              <a href="#" className="text-gray-300 hover:text-red-400 px-3 py-2 rounded-md text-sm font-medium">
                Live
              </a>
              {(user.tier === 'contributor' || user.tier === 'admin') && (
                <a href="#" className="text-gray-300 hover:text-red-400 px-3 py-2 rounded-md text-sm font-medium">
                  Upload
                </a>
              )}
              {user.tier === 'admin' && (
                <Link href="/admin">
                  <a className="text-gray-300 hover:text-red-400 px-3 py-2 rounded-md text-sm font-medium">
                    Admin
                  </a>
                </Link>
              )}
            </div>
          </div>

          {/* User Actions */}
          <div className="flex items-center space-x-4">
            <div className="hidden sm:block">
              {getTierBadge(user.tier)}
            </div>
            
            {getUpgradeButton()}

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user.profileImageUrl} alt={user.firstName || 'User'} />
                    <AvatarFallback>
                      {user.firstName?.charAt(0) || user.email?.charAt(0) || 'U'}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56 bg-gray-800 border-gray-700" align="end" forceMount>
                <DropdownMenuItem className="hover:bg-gray-700">
                  <Link href="/profile">
                    <div className="flex items-center w-full">
                      <User className="mr-2 h-4 w-4" />
                      <span>Profile</span>
                    </div>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem className="hover:bg-gray-700">
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Settings</span>
                </DropdownMenuItem>
                {user.tier === 'admin' && (
                  <DropdownMenuItem className="hover:bg-gray-700">
                    <Link href="/admin">
                      <div className="flex items-center">
                        <Shield className="mr-2 h-4 w-4" />
                        <span>Admin Panel</span>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem 
                  className="hover:bg-gray-700"
                  onClick={() => window.location.href = "/api/logout"}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </nav>
  );
}
