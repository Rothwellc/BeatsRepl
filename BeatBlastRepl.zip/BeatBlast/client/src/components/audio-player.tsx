import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Play, Pause, Volume2, VolumeX, SkipBack, SkipForward, Clock } from "lucide-react";
import { checkTierAccess, TierRestrictionModal } from "./tier-restrictions";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface AudioPlayerProps {
  track: {
    id: string;
    title: string;
    artist: string;
    duration: number;
    audioUrl?: string;
    coverArtUrl?: string;
    accessType?: string;
  };
  onNext?: () => void;
  onPrevious?: () => void;
  onPlay?: (trackId: string) => void;
  className?: string;
}

export default function AudioPlayer({ track, onNext, onPrevious, onPlay, className }: AudioPlayerProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const audioRef = useRef<HTMLAudioElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [showRestriction, setShowRestriction] = useState(false);
  const [isPreviewMode, setIsPreviewMode] = useState(false);

  const userTier = user?.tier || 'free';
  const canStreamFull = checkTierAccess(userTier, 'streaming');
  const canPreview = checkTierAccess(userTier, 'previews');
  
  // Determine playback mode
  const maxPlayTime = canStreamFull ? track.duration : (canPreview ? 30 : 0);
  
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const updateTime = () => setCurrentTime(audio.currentTime);
    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
      if (onNext) onNext();
    };

    // For preview mode, stop at 30 seconds
    const handleTimeUpdate = () => {
      updateTime();
      if (!canStreamFull && canPreview && audio.currentTime >= 30) {
        audio.pause();
        setIsPlaying(false);
        toast({
          title: "Preview Ended",
          description: "Upgrade to Premium for full tracks",
          variant: "default",
        });
      }
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
    };
  }, [canStreamFull, canPreview, onNext, toast]);

  const handlePlay = () => {
    if (!canPreview && !canStreamFull) {
      setShowRestriction(true);
      return;
    }

    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().then(() => {
        setIsPlaying(true);
        onPlay?.(track.id);
        
        // Show preview mode notification
        if (!canStreamFull && canPreview) {
          setIsPreviewMode(true);
          toast({
            title: "Preview Mode",
            description: "Playing 30-second preview. Upgrade for full tracks.",
            variant: "default",
          });
        }
      }).catch((error) => {
        console.error('Audio play failed:', error);
        toast({
          title: "Playback Error",
          description: "Unable to play this track",
          variant: "destructive",
        });
      });
    }
  };

  const handleSeek = (value: number[]) => {
    const audio = audioRef.current;
    if (!audio) return;
    
    const newTime = Math.min(value[0], maxPlayTime);
    audio.currentTime = newTime;
    setCurrentTime(newTime);
  };

  const handleVolumeChange = (value: number[]) => {
    const audio = audioRef.current;
    if (!audio) return;
    
    const newVolume = value[0];
    setVolume(newVolume);
    audio.volume = newVolume;
    setIsMuted(newVolume === 0);
  };

  const toggleMute = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isMuted) {
      audio.volume = volume;
      setIsMuted(false);
    } else {
      audio.volume = 0;
      setIsMuted(true);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getAccessBadge = () => {
    if (!canPreview && !canStreamFull) {
      return <Badge variant="destructive" className="text-xs">Restricted</Badge>;
    }
    if (!canStreamFull && canPreview) {
      return <Badge variant="outline" className="text-xs border-yellow-600 text-yellow-400">Preview Only</Badge>;
    }
    if (canStreamFull) {
      return <Badge variant="default" className="text-xs bg-green-600">Full Track</Badge>;
    }
  };

  if (showRestriction) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowRestriction(false)}>
        <div onClick={(e) => e.stopPropagation()}>
          <TierRestrictionModal 
            currentTier={userTier} 
            feature="streaming" 
            onUpgrade={() => {
              setShowRestriction(false);
              window.location.href = "/signup";
            }}
          />
        </div>
      </div>
    );
  }

  return (
    <Card className={`bg-gray-800 border-gray-700 ${className}`}>
      <CardContent className="p-4">
        <audio
          ref={audioRef}
          src={track.audioUrl || "/audio/sample-track.mp3"}
          preload="metadata"
        />
        
        <div className="flex items-center space-x-4">
          {/* Track Info */}
          <div className="flex items-center space-x-3 flex-1 min-w-0">
            <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-red-800 rounded-lg flex items-center justify-center flex-shrink-0">
              {track.coverArtUrl ? (
                <img 
                  src={track.coverArtUrl} 
                  alt={track.title}
                  className="w-full h-full object-cover rounded-lg"
                />
              ) : (
                <Play className="h-6 w-6 text-white" />
              )}
            </div>
            <div className="min-w-0 flex-1">
              <h4 className="font-medium truncate">{track.title}</h4>
              <p className="text-sm text-gray-400 truncate">{track.artist}</p>
              <div className="flex items-center space-x-2 mt-1">
                {getAccessBadge()}
                {isPreviewMode && (
                  <Badge variant="outline" className="text-xs border-blue-600 text-blue-400">
                    <Clock className="w-3 h-3 mr-1" />
                    30s Preview
                  </Badge>
                )}
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center space-x-2">
            {onPrevious && (
              <Button variant="ghost" size="sm" onClick={onPrevious}>
                <SkipBack className="h-4 w-4" />
              </Button>
            )}
            
            <Button
              variant="ghost"
              size="sm"
              onClick={handlePlay}
              className="w-10 h-10 rounded-full cool-red-gradient hover:bg-red-700"
            >
              {isPlaying ? (
                <Pause className="h-5 w-5 text-white" />
              ) : (
                <Play className="h-5 w-5 text-white" />
              )}
            </Button>

            {onNext && (
              <Button variant="ghost" size="sm" onClick={onNext}>
                <SkipForward className="h-4 w-4" />
              </Button>
            )}
          </div>

          {/* Volume */}
          <div className="flex items-center space-x-2 min-w-[100px]">
            <Button variant="ghost" size="sm" onClick={toggleMute}>
              {isMuted || volume === 0 ? (
                <VolumeX className="h-4 w-4" />
              ) : (
                <Volume2 className="h-4 w-4" />
              )}
            </Button>
            <Slider
              value={[isMuted ? 0 : volume]}
              onValueChange={handleVolumeChange}
              max={1}
              step={0.1}
              className="w-16"
            />
          </div>

          {/* Time */}
          <div className="text-sm text-gray-400 min-w-[80px] text-center">
            {formatTime(currentTime)} / {formatTime(maxPlayTime)}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mt-3">
          <Slider
            value={[currentTime]}
            onValueChange={handleSeek}
            max={maxPlayTime}
            step={1}
            className="w-full"
          />
        </div>

        {/* Restriction Notice */}
        {!canStreamFull && canPreview && (
          <div className="mt-2 text-center">
            <p className="text-xs text-yellow-400">
              Preview mode - Upgrade to Premium for full tracks
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}