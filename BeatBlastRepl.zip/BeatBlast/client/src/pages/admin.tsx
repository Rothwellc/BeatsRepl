import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Navigation from "@/components/layout/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  CheckCircle, 
  XCircle, 
  Music, 
  Users, 
  TrendingUp, 
  Calendar,
  Settings
} from "lucide-react";
import type { Track, User } from "@/types/music";

export default function Admin() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Redirect if not admin
  useEffect(() => {
    if (!isLoading && (!user || user.tier !== 'admin')) {
      toast({
        title: "Unauthorized",
        description: "Admin access required.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/";
      }, 500);
      return;
    }
  }, [user, isLoading, toast]);

  const { data: pendingTracks } = useQuery<Track[]>({
    queryKey: ["/api/admin/tracks/pending"],
    retry: false,
    enabled: user?.tier === 'admin',
  });

  const { data: topTracks } = useQuery<Track[]>({
    queryKey: ["/api/analytics/top-tracks"],
    retry: false,
  });

  const { data: genreStats } = useQuery<any[]>({
    queryKey: ["/api/analytics/genres"],
    retry: false,
  });

  const approveTrackMutation = useMutation({
    mutationFn: async (trackId: string) => {
      await apiRequest("POST", `/api/admin/tracks/${trackId}/approve`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/tracks/pending"] });
      toast({
        title: "Track approved",
        description: "The track has been approved and is now live.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to approve track.",
        variant: "destructive",
      });
    },
  });

  const rejectTrackMutation = useMutation({
    mutationFn: async (trackId: string) => {
      await apiRequest("POST", `/api/admin/tracks/${trackId}/reject`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/tracks/pending"] });
      toast({
        title: "Track rejected",
        description: "The track has been rejected.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to reject track.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  if (!user || user.tier !== 'admin') {
    return null; // Will redirect via useEffect
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Navigation user={user} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-gray-400">Manage content, users, and platform analytics</p>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-400">Pending Tracks</p>
                  <p className="text-2xl font-bold">{pendingTracks?.length || 0}</p>
                </div>
                <Music className="h-8 w-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-400">Total Genres</p>
                  <p className="text-2xl font-bold">{genreStats?.length || 0}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-400">Top Plays</p>
                  <p className="text-2xl font-bold">{topTracks?.[0]?.playCount || 0}</p>
                </div>
                <Users className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-400">This Month</p>
                  <p className="text-2xl font-bold">{new Date().toLocaleDateString('en-US', { month: 'short' })}</p>
                </div>
                <Calendar className="h-8 w-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Admin Tabs */}
        <Tabs defaultValue="pending" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-gray-800">
            <TabsTrigger value="pending">Pending Tracks</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="genres">Genres</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="pending">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Music className="h-5 w-5" />
                  Pending Track Approvals
                </CardTitle>
              </CardHeader>
              <CardContent>
                {!pendingTracks || pendingTracks.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">
                    <Music className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No pending tracks to review</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pendingTracks.map((track) => (
                      <div key={track.id} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gray-600 rounded-lg flex items-center justify-center overflow-hidden">
                            {track.coverArtUrl ? (
                              <img 
                                src={track.coverArtUrl} 
                                alt={track.title}
                                className="w-full h-full object-cover" 
                              />
                            ) : (
                              <Music className="h-6 w-6 text-gray-400" />
                            )}
                          </div>
                          <div>
                            <h4 className="font-semibold">{track.title}</h4>
                            <p className="text-sm text-gray-400">{track.artist}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant="outline" className="text-xs">
                                {track.genre}
                              </Badge>
                              <Badge variant="outline" className="text-xs">
                                {track.accessType}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button
                            onClick={() => approveTrackMutation.mutate(track.id)}
                            disabled={approveTrackMutation.isPending}
                            size="sm"
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Approve
                          </Button>
                          <Button
                            onClick={() => rejectTrackMutation.mutate(track.id)}
                            disabled={rejectTrackMutation.isPending}
                            size="sm"
                            variant="destructive"
                          >
                            <XCircle className="h-4 w-4 mr-1" />
                            Reject
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle>Top Tracks</CardTitle>
                </CardHeader>
                <CardContent>
                  {topTracks?.slice(0, 5).map((track, index) => (
                    <div key={track.id} className="flex items-center justify-between py-2">
                      <div className="flex items-center space-x-3">
                        <span className="text-gray-400 w-6">{index + 1}</span>
                        <div>
                          <p className="font-medium">{track.title}</p>
                          <p className="text-sm text-gray-400">{track.artist}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{track.playCount} plays</p>
                        <p className="text-sm text-gray-400">★ {track.averageRating}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle>Platform Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Total Tracks</span>
                      <span className="font-medium">{topTracks?.length || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Active Genres</span>
                      <span className="font-medium">{genreStats?.length || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Total Plays</span>
                      <span className="font-medium">
                        {genreStats?.reduce((sum, genre) => sum + (genre.totalPlays || 0), 0) || 0}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="genres">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>Genre Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {genreStats?.map((genre) => (
                    <div key={genre.genre} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                      <div>
                        <h4 className="font-semibold">{genre.genre}</h4>
                        <p className="text-sm text-gray-400">{genre.count} tracks</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{genre.totalPlays || 0} total plays</p>
                        <p className="text-sm text-gray-400">
                          {Math.round((genre.totalPlays || 0) / (genre.count || 1))} avg plays
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Platform Settings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-gray-400">
                  <Settings className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Platform settings coming soon...</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
