import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import Navigation from "@/components/layout/navigation";
import UpgradeBanner from "@/components/upgrade-banner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  User, 
  Music, 
  Clock, 
  Heart, 
  Settings, 
  Plus, 
  ShoppingCart, 
  DollarSign, 
  Download,
  PlayCircle,
  Star,
  Crown,
  Headphones
} from "lucide-react";
import type { Track } from "@/types/music";

interface PlayHistory {
  id: string;
  trackId: string;
  playedAt: string;
  duration: number;
  track?: Track;
}

interface Playlist {
  id: string;
  name: string;
  description: string;
  trackCount: number;
  createdAt: string;
  tracks?: Track[];
}

export default function Profile() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreatePlaylistOpen, setIsCreatePlaylistOpen] = useState(false);
  const [playlistName, setPlaylistName] = useState("");
  const [playlistDescription, setPlaylistDescription] = useState("");

  const { data: recentTracks } = useQuery<PlayHistory[]>({
    queryKey: ["/api/user/history"],
    retry: false,
    enabled: !!user,
  });

  const { data: likedTracks } = useQuery<Track[]>({
    queryKey: ["/api/user/liked"],
    retry: false,
    enabled: !!user,
  });

  const { data: userPlaylists } = useQuery<Playlist[]>({
    queryKey: ["/api/user/playlists"],
    retry: false,
    enabled: !!user && (user.tier === 'prepaid' || user.tier === 'contributor'),
  });

  const { data: purchasedTracks } = useQuery<Track[]>({
    queryKey: ["/api/user/purchases"],
    retry: false,
    enabled: !!user,
  });

  const createPlaylistMutation = useMutation({
    mutationFn: async (data: { name: string; description: string }) => {
      await apiRequest("POST", "/api/user/playlists", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/playlists"] });
      setIsCreatePlaylistOpen(false);
      setPlaylistName("");
      setPlaylistDescription("");
      toast({
        title: "Playlist Created",
        description: "Your new playlist has been created successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create playlist. Please try again.",
        variant: "destructive",
      });
    },
  });

  const purchaseTrackMutation = useMutation({
    mutationFn: async (trackId: string) => {
      await apiRequest("POST", `/api/tracks/${trackId}/purchase`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/purchases"] });
      toast({
        title: "Purchase Successful",
        description: "Track has been added to your collection.",
      });
    },
    onError: (error) => {
      toast({
        title: "Purchase Failed",
        description: "Failed to purchase track. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCreatePlaylist = () => {
    if (!playlistName.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter a playlist name.",
        variant: "destructive",
      });
      return;
    }
    createPlaylistMutation.mutate({ name: playlistName, description: playlistDescription });
  };

  const handlePurchaseTrack = (trackId: string) => {
    purchaseTrackMutation.mutate(trackId);
  };

  if (isLoading) {
    return <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
      <div className="text-xl">Loading...</div>
    </div>;
  }

  if (!user) {
    return <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-2xl font-bold mb-4">Profile Not Found</h1>
        <p className="text-gray-400">Please log in to view your profile</p>
      </div>
    </div>;
  }

  const getTierIcon = (tier: string) => {
    switch (tier) {
      case 'contributor': return Crown;
      case 'prepaid': return Star;
      default: return User;
    }
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'contributor': return 'from-purple-600 to-purple-800';
      case 'prepaid': return 'from-red-600 to-red-800';
      default: return 'from-green-600 to-green-800';
    }
  };

  const getTierName = (tier: string) => {
    switch (tier) {
      case 'contributor': return 'Contributor';
      case 'prepaid': return 'Premium';
      case 'subscriber': return 'Free Subscriber';
      default: return 'Free User';
    }
  };

  const TierIcon = getTierIcon(user.tier);

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Navigation user={user} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Upgrade Banner for non-contributor users */}
        {user.tier !== 'contributor' && (
          <UpgradeBanner currentTier={user.tier} />
        )}

        {/* Profile Header */}
        <div className="mb-8">
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-8">
              <div className="flex items-center space-x-6">
                {/* Profile Image */}
                <div className="relative">
                  {user.profileImageUrl ? (
                    <img
                      src={user.profileImageUrl}
                      alt={user.firstName || 'User'}
                      className="w-24 h-24 rounded-full object-cover border-4 border-gray-600"
                    />
                  ) : (
                    <div className="w-24 h-24 rounded-full bg-gray-600 flex items-center justify-center border-4 border-gray-500">
                      <User className="h-12 w-12 text-gray-300" />
                    </div>
                  )}
                  {/* Tier Badge */}
                  <div className={`absolute -bottom-2 -right-2 w-10 h-10 rounded-full bg-gradient-to-br ${getTierColor(user.tier)} flex items-center justify-center border-2 border-gray-800`}>
                    <TierIcon className="h-5 w-5 text-white" />
                  </div>
                </div>

                {/* Profile Info */}
                <div className="flex-1">
                  <h1 className="text-3xl font-bold mb-2">
                    {user.firstName && user.lastName ? `${user.firstName} ${user.lastName}` : 'Music Lover'}
                  </h1>
                  <p className="text-gray-300 mb-4">{user.email}</p>
                  <div className="flex items-center space-x-4">
                    <Badge className={`bg-gradient-to-r ${getTierColor(user.tier)} text-white border-none`}>
                      {getTierName(user.tier)}
                    </Badge>
                    <div className="flex items-center text-sm text-gray-400">
                      <Music className="h-4 w-4 mr-1" />
                      {recentTracks?.length || 0} tracks played
                    </div>
                    <div className="flex items-center text-sm text-gray-400">
                      <Heart className="h-4 w-4 mr-1" />
                      {likedTracks?.length || 0} tracks liked
                    </div>
                  </div>
                </div>

                {/* Profile Actions */}
                <div className="flex flex-col space-y-2">
                  <Button variant="outline" className="border-gray-600">
                    <Settings className="mr-2 h-4 w-4" />
                    Settings
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Profile Content Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-gray-800 border-gray-700">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="history">Listening History</TabsTrigger>
            <TabsTrigger value="liked">Liked Tracks</TabsTrigger>
            {(user.tier === 'prepaid' || user.tier === 'contributor') && (
              <TabsTrigger value="playlists">My Playlists</TabsTrigger>
            )}
            <TabsTrigger value="purchases">Purchases</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-6">
              {/* Listening Stats */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Headphones className="mr-2 h-5 w-5" />
                    Listening Stats
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Total Plays</span>
                      <span className="font-semibold">{recentTracks?.length || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Liked Tracks</span>
                      <span className="font-semibold">{likedTracks?.length || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Playlists</span>
                      <span className="font-semibold">{userPlaylists?.length || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Purchases</span>
                      <span className="font-semibold">{purchasedTracks?.length || 0}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Clock className="mr-2 h-5 w-5" />
                    Recent Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {recentTracks?.slice(0, 5).map((play) => (
                      <div key={play.id} className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-red-600 rounded flex items-center justify-center">
                          <Music className="h-4 w-4 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">Recently played track</p>
                          <p className="text-xs text-gray-400">
                            {new Date(play.playedAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    )) || (
                      <p className="text-gray-400 text-sm">No recent activity</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Tier Benefits */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TierIcon className="mr-2 h-5 w-5" />
                    Your Benefits
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {user.tier === 'contributor' && (
                      <>
                        <div className="flex items-center text-sm">
                          <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
                          Upload unlimited tracks
                        </div>
                        <div className="flex items-center text-sm">
                          <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
                          Revenue sharing
                        </div>
                        <div className="flex items-center text-sm">
                          <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
                          Artist analytics
                        </div>
                      </>
                    )}
                    {user.tier === 'prepaid' && (
                      <>
                        <div className="flex items-center text-sm">
                          <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
                          Unlimited streaming
                        </div>
                        <div className="flex items-center text-sm">
                          <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
                          Create playlists
                        </div>
                        <div className="flex items-center text-sm">
                          <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
                          Download tracks
                        </div>
                      </>
                    )}
                    {user.tier === 'subscriber' && (
                      <>
                        <div className="flex items-center text-sm">
                          <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
                          30-second previews
                        </div>
                        <div className="flex items-center text-sm">
                          <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
                          Community access
                        </div>
                        <div className="flex items-center text-sm">
                          <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
                          Social sharing
                        </div>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Listening History Tab */}
          <TabsContent value="history">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>Recent Listening History</CardTitle>
              </CardHeader>
              <CardContent>
                {recentTracks?.length ? (
                  <div className="space-y-4">
                    {recentTracks.map((play) => (
                      <div key={play.id} className="flex items-center justify-between p-4 bg-gray-750 rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center">
                            <Music className="h-6 w-6 text-white" />
                          </div>
                          <div>
                            <p className="font-medium">Track {play.trackId.slice(0, 8)}</p>
                            <p className="text-sm text-gray-400">
                              Played {new Date(play.playedAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <Button size="sm" variant="outline" className="border-gray-600">
                          <PlayCircle className="mr-2 h-4 w-4" />
                          Play Again
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-400 text-center py-8">No listening history yet</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Liked Tracks Tab */}
          <TabsContent value="liked">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>Liked Tracks</CardTitle>
              </CardHeader>
              <CardContent>
                {likedTracks?.length ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {likedTracks.map((track) => (
                      <div key={track.id} className="bg-gray-750 rounded-lg p-4">
                        <div className="aspect-square bg-gray-600 rounded-lg mb-3 flex items-center justify-center">
                          <Music className="h-8 w-8 text-gray-400" />
                        </div>
                        <h3 className="font-medium truncate">{track.title}</h3>
                        <p className="text-sm text-gray-400 truncate">{track.artist}</p>
                        <div className="flex items-center justify-between mt-3">
                          <Button size="sm" className="bg-red-600 hover:bg-red-700">
                            <PlayCircle className="h-4 w-4" />
                          </Button>
                          <Heart className="h-4 w-4 text-red-400 fill-current" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-400 text-center py-8">No liked tracks yet</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Playlists Tab (Premium/Contributor only) */}
          {(user.tier === 'prepaid' || user.tier === 'contributor') && (
            <TabsContent value="playlists">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold">My Playlists</h2>
                  <Dialog open={isCreatePlaylistOpen} onOpenChange={setIsCreatePlaylistOpen}>
                    <DialogTrigger asChild>
                      <Button className="bg-red-600 hover:bg-red-700">
                        <Plus className="mr-2 h-4 w-4" />
                        Create Playlist
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-gray-800 border-gray-700">
                      <DialogHeader>
                        <DialogTitle>Create New Playlist</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="playlist-name">Playlist Name</Label>
                          <Input
                            id="playlist-name"
                            value={playlistName}
                            onChange={(e) => setPlaylistName(e.target.value)}
                            placeholder="Enter playlist name"
                            className="bg-gray-700 border-gray-600"
                          />
                        </div>
                        <div>
                          <Label htmlFor="playlist-description">Description (Optional)</Label>
                          <Textarea
                            id="playlist-description"
                            value={playlistDescription}
                            onChange={(e) => setPlaylistDescription(e.target.value)}
                            placeholder="Describe your playlist"
                            className="bg-gray-700 border-gray-600"
                          />
                        </div>
                        <div className="flex justify-end space-x-2">
                          <Button 
                            variant="outline" 
                            onClick={() => setIsCreatePlaylistOpen(false)}
                            className="border-gray-600"
                          >
                            Cancel
                          </Button>
                          <Button 
                            onClick={handleCreatePlaylist}
                            disabled={createPlaylistMutation.isPending}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            {createPlaylistMutation.isPending ? "Creating..." : "Create"}
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {userPlaylists?.map((playlist) => (
                    <Card key={playlist.id} className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
                      <CardContent className="p-6">
                        <div className="aspect-square bg-gradient-to-br from-red-600 to-red-800 rounded-lg mb-4 flex items-center justify-center">
                          <Music className="h-12 w-12 text-white" />
                        </div>
                        <h3 className="font-semibold mb-2">{playlist.name}</h3>
                        <p className="text-sm text-gray-400 mb-4 line-clamp-2">
                          {playlist.description || "No description"}
                        </p>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-400">
                            {playlist.trackCount} tracks
                          </span>
                          <Button size="sm" variant="outline" className="border-gray-600">
                            Open
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  )) || (
                    <div className="col-span-full text-center py-12">
                      <Music className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold mb-2">No playlists yet</h3>
                      <p className="text-gray-400 mb-6">Create your first playlist to organize your favorite tracks</p>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
          )}

          {/* Purchases Tab */}
          <TabsContent value="purchases">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>Your Purchases</CardTitle>
              </CardHeader>
              <CardContent>
                {purchasedTracks?.length ? (
                  <div className="space-y-4">
                    {purchasedTracks.map((track) => (
                      <div key={track.id} className="flex items-center justify-between p-4 bg-gray-750 rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center">
                            <Music className="h-6 w-6 text-white" />
                          </div>
                          <div>
                            <p className="font-medium">{track.title}</p>
                            <p className="text-sm text-gray-400">{track.artist}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button size="sm" variant="outline" className="border-gray-600">
                            <Download className="mr-2 h-4 w-4" />
                            Download
                          </Button>
                          <Button size="sm" className="bg-red-600 hover:bg-red-700">
                            <PlayCircle className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <ShoppingCart className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold mb-2">No purchases yet</h3>
                    <p className="text-gray-400 mb-6">Support artists by purchasing their tracks</p>
                    <Button className="bg-red-600 hover:bg-red-700">
                      <ShoppingCart className="mr-2 h-4 w-4" />
                      Browse Tracks
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}