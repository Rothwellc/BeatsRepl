import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import Navigation from "@/components/layout/navigation";
import UpgradeBanner from "@/components/upgrade-banner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  User, 
  Music, 
  Clock, 
  Heart, 
  Settings, 
  Plus, 
  ShoppingCart, 
  DollarSign, 
  Download,
  PlayCircle,
  Star,
  Crown,
  Headphones
} from "lucide-react";
import type { Track } from "@/types/music";

interface PlayHistory {
  id: string;
  trackId: string;
  playedAt: string;
  duration: number;
  track?: Track;
}

interface Playlist {
  id: string;
  name: string;
  description: string;
  trackCount: number;
  createdAt: string;
  tracks?: Track[];
}

export default function Profile() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreatePlaylistOpen, setIsCreatePlaylistOpen] = useState(false);
  const [playlistName, setPlaylistName] = useState("");
  const [playlistDescription, setPlaylistDescription] = useState("");

  const { data: recentTracks } = useQuery<PlayHistory[]>({
    queryKey: ["/api/user/history"],
    retry: false,
    enabled: !!user,
  });

  const { data: likedTracks } = useQuery<Track[]>({
    queryKey: ["/api/user/liked"],
    retry: false,
    enabled: !!user,
  });

  if (isLoading) {
    return <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
      <div className="text-xl">Loading...</div>
    </div>;
  }

  if (!user) {
    return <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-2xl font-bold mb-4">Profile Not Found</h1>
        <p className="text-gray-400">Please log in to view your profile</p>
      </div>
    </div>;
  }

  const tierColors = {
    free: "bg-gray-600",
    subscriber: "bg-blue-600", 
    prepaid: "bg-purple-600",
    contributor: "bg-green-600",
    admin: "bg-red-600"
  };

  const tierLabels = {
    free: "Free User",
    subscriber: "Subscriber",
    prepaid: "Premium", 
    contributor: "Contributor",
    admin: "Administrator"
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Navigation user={user} />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Header */}
        <div className="mb-8">
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center">
                  {user.profileImageUrl ? (
                    <img 
                      src={user.profileImageUrl} 
                      alt="Profile" 
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    <User className="h-10 w-10 text-white" />
                  )}
                </div>
                <div className="flex-1">
                  <h1 className="text-2xl font-bold">
                    {user.firstName && user.lastName 
                      ? `${user.firstName} ${user.lastName}`
                      : user.email
                    }
                  </h1>
                  <p className="text-gray-400">{user.email}</p>
                  <div className="flex items-center space-x-2 mt-2">
                    <Badge className={`${tierColors[user.tier]} text-white`}>
                      {tierLabels[user.tier]}
                    </Badge>
                    <span className="text-sm text-gray-400">
                      Member since {new Date(user.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                <Button variant="outline" className="border-gray-600">
                  <Settings className="h-4 w-4 mr-2" />
                  Edit Profile
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Profile Tabs */}
        <Tabs defaultValue="activity" className="space-y-6">
          <TabsList className="bg-gray-800 border-gray-700">
            <TabsTrigger value="activity" className="data-[state=active]:bg-red-600">
              <Clock className="h-4 w-4 mr-2" />
              Recent Activity
            </TabsTrigger>
            <TabsTrigger value="liked" className="data-[state=active]:bg-red-600">
              <Heart className="h-4 w-4 mr-2" />
              Liked Tracks
            </TabsTrigger>
            <TabsTrigger value="playlists" className="data-[state=active]:bg-red-600">
              <Music className="h-4 w-4 mr-2" />
              Playlists
            </TabsTrigger>
          </TabsList>

          <TabsContent value="activity" className="space-y-4">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>Recently Played</CardTitle>
              </CardHeader>
              <CardContent>
                {recentTracks && recentTracks.length > 0 ? (
                  <div className="space-y-3">
                    {recentTracks.slice(0, 10).map((play, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-red-600 rounded flex items-center justify-center">
                            <Music className="h-5 w-5 text-white" />
                          </div>
                          <div>
                            <p className="font-medium">Track #{index + 1}</p>
                            <p className="text-sm text-gray-400">Recently played</p>
                          </div>
                        </div>
                        <span className="text-sm text-gray-400">
                          {new Date().toLocaleDateString()}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-400 text-center py-8">No recent activity</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="liked" className="space-y-4">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>Liked Tracks</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400 text-center py-8">
                  Start liking tracks to see them here
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="playlists" className="space-y-4">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>Your Playlists</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Music className="h-12 w-12 text-gray-500 mx-auto mb-4" />
                  <p className="text-gray-400 mb-4">No playlists yet</p>
                  <Button className="cool-red-gradient">
                    Create Your First Playlist
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}