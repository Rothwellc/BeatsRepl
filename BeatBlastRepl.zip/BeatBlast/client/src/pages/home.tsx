import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Navigation from "@/components/layout/navigation";
import MusicPlayer from "@/components/layout/music-player";
import TrackCard from "@/components/ui/track-card";
import UploadModal from "@/components/ui/upload-modal";
import UpgradeBanner from "@/components/upgrade-banner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Upload, Play, Radio, TrendingUp } from "lucide-react";
import type { Track, LiveStream, User } from "@/types/music";

export default function Home() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, isLoading, toast]);

  const { data: featuredTracks } = useQuery<Track[]>({
    queryKey: ["/api/tracks/featured"],
    retry: false,
  });

  const { data: trendingTracks } = useQuery<Track[]>({
    queryKey: ["/api/tracks/trending"],
    retry: false,
  });

  const { data: liveStream } = useQuery<LiveStream | null>({
    queryKey: ["/api/live-stream"],
    retry: false,
    refetchInterval: 30000,
  });

  const { data: tracks } = useQuery<Track[]>({
    queryKey: ["/api/tracks"],
    retry: false,
  });

  const playTrackMutation = useMutation({
    mutationFn: async (data: { trackId: string; duration: number }) => {
      await apiRequest("POST", `/api/tracks/${data.trackId}/play`, { duration: data.duration });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      console.error("Error recording play:", error);
    },
  });

  const handlePlayTrack = (track: Track) => {
    // Check tier restrictions
    if (track.accessType === 'paid' && (!user || user.tier === 'free')) {
      toast({
        title: "Premium Required",
        description: "This track requires a premium subscription.",
        variant: "destructive",
      });
      return;
    }

    setCurrentTrack(track);
    setIsPlaying(true);
    
    // Record play
    playTrackMutation.mutate({ trackId: track.id, duration: track.duration });
  };

  const handleUploadSuccess = () => {
    setIsUploadModalOpen(false);
    queryClient.invalidateQueries({ queryKey: ["/api/tracks"] });
    toast({
      title: "Track uploaded successfully",
      description: "Your track is now pending review.",
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return null; // Will redirect via useEffect
  }

  const genres = [
    { name: "Deep House", color: "from-red-600 to-red-800" },
    { name: "Tech House", color: "from-purple-600 to-purple-800" },
    { name: "Progressive", color: "from-blue-600 to-blue-800" },
    { name: "Minimal", color: "from-green-600 to-green-800" },
  ];

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {user && <Navigation user={user} />}

      {/* Live Stream Banner */}
      {liveStream?.isLive && (
        <div className="cool-red-gradient p-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-3 h-3 bg-white rounded-full audio-wave"></div>
              <span className="font-semibold">LIVE NOW</span>
              <span className="text-red-100">{liveStream.djName}</span>
              <span className="text-red-200 text-sm">{liveStream.title}</span>
            </div>
            <Button variant="secondary" className="bg-white/20 hover:bg-white/30">
              <Radio className="mr-2 h-4 w-4" />
              Watch Live
            </Button>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Upgrade Banner for non-contributor users */}
        {user && user.tier !== 'contributor' && (
          <UpgradeBanner currentTier={user.tier} />
        )}

        {/* Live Stream Embed */}
        {liveStream && (
          <div className="mb-12">
            <Card className="bg-gray-800 border-gray-700 overflow-hidden shadow-2xl">
              <div className="aspect-video bg-black relative">
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center mb-4 mx-auto">
                      <Radio className="text-white h-8 w-8" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">Live DJ Set</h3>
                    <p className="text-gray-300">Experience the underground</p>
                  </div>
                </div>
              </div>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold">{liveStream.title}</h3>
                    <p className="text-gray-400">{liveStream.description}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-red-400 text-sm">●</span>
                    <span className="text-sm">{liveStream.viewerCount} watching</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Contributor Upload Section */}
        {user && (user.tier === 'contributor' || user.tier === 'admin') && (
          <section className="mb-12">
            <div className="cool-red-gradient rounded-xl p-8">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold mb-2">Share Your Music</h2>
                  <p className="text-red-100">Upload tracks and reach thousands of house music fans</p>
                </div>
                <Button 
                  onClick={() => setIsUploadModalOpen(true)}
                  className="bg-white text-red-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100"
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Upload Track
                </Button>
              </div>
            </div>
          </section>
        )}

        {/* Music Content Tabs */}
        <Tabs defaultValue="featured" className="mb-12">
          <TabsList className="grid w-full grid-cols-4 bg-gray-800">
            <TabsTrigger value="featured">Featured</TabsTrigger>
            <TabsTrigger value="trending">
              <TrendingUp className="mr-2 h-4 w-4" />
              Trending
            </TabsTrigger>
            <TabsTrigger value="genres">Genres</TabsTrigger>
            <TabsTrigger value="all">All Tracks</TabsTrigger>
          </TabsList>

          <TabsContent value="featured" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-3xl font-bold">Featured Tracks</h2>
              <Badge variant="outline" className="border-red-600 text-red-400">
                Curated Selection
              </Badge>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {featuredTracks?.map((track) => (
                <TrackCard 
                  key={track.id} 
                  track={track} 
                  userTier={user?.tier || 'free'} 
                  onPlay={() => handlePlayTrack(track)}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="trending" className="space-y-6">
            <h2 className="text-3xl font-bold">Trending Now</h2>
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                {trendingTracks?.map((track, index) => (
                  <div key={track.id} className="flex items-center p-4 hover:bg-gray-700 rounded-lg transition-colors group">
                    <div className="text-gray-400 w-8 text-center font-semibold">{index + 1}</div>
                    <div className="w-12 h-12 rounded-lg mx-4 bg-gray-600 flex items-center justify-center overflow-hidden">
                      {track.coverArtUrl ? (
                        <img 
                          src={track.coverArtUrl} 
                          alt={track.title}
                          className="w-full h-full object-cover" 
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center">
                          <span className="text-white text-xs">{track.title.charAt(0)}</span>
                        </div>
                      )}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold">{track.title}</h4>
                      <p className="text-gray-400 text-sm">{track.artist}</p>
                    </div>
                    <div className="text-gray-400 text-sm">
                      {Math.floor(track.duration / 60)}:{(track.duration % 60).toString().padStart(2, '0')}
                    </div>
                    <Button 
                      onClick={() => handlePlayTrack(track)}
                      size="sm" 
                      className="ml-4 opacity-0 group-hover:opacity-100 w-8 h-8 rounded-full cool-red-gradient hover:bg-red-700"
                    >
                      <Play className="h-3 w-3 text-white" />
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="genres" className="space-y-6">
            <h2 className="text-3xl font-bold">Browse by Genre</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {genres.map((genre) => (
                <Card 
                  key={genre.name}
                  className={`bg-gradient-to-br ${genre.color} border-0 p-6 hover:scale-105 transition-all cursor-pointer`}
                >
                  <CardContent className="p-0">
                    <h3 className="text-xl font-bold mb-2">{genre.name}</h3>
                    <p className="text-white/80 text-sm">Explore tracks</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="all" className="space-y-6">
            <h2 className="text-3xl font-bold">All Tracks</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {tracks?.map((track) => (
                <TrackCard 
                  key={track.id} 
                  track={track} 
                  userTier={user?.tier || 'free'} 
                  onPlay={() => handlePlayTrack(track)}
                />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Music Player */}
      {currentTrack && (
        <MusicPlayer 
          track={currentTrack} 
          isPlaying={isPlaying} 
          userTier={user.tier}
          onPlayPause={() => setIsPlaying(!isPlaying)}
        />
      )}

      {/* Upload Modal */}
      <UploadModal 
        isOpen={isUploadModalOpen} 
        onClose={() => setIsUploadModalOpen(false)}
        onUploadSuccess={handleUploadSuccess}
      />
    </div>
  );
}
