import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Play, TrendingUp, Music, Radio, Users, Star, Crown, Calendar, Clock, Award, Volume2, Heart, Share2, Download, Disc, Headphones, Palette, UserCheck, Instagram, Twitter, Facebook, Youtube, Mail, MapPin, Phone } from "lucide-react";
import type { Track, LiveStream } from "@/types/music";
import AudioPlayer from "@/components/audio-player";
import { TierFeaturesDisplay } from "@/components/tier-restrictions";
import TierSelectionModal from "@/components/tier-selection-modal";
import { useAuth } from "@/hooks/useAuth";
import { useState } from "react";
import bestBeatsLogo from "@assets/Bb2_1754377368688.png";

export default function Landing() {
  const { user } = useAuth();
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [showTierModal, setShowTierModal] = useState(false);


  const { data: featuredTracks } = useQuery<Track[]>({
    queryKey: ["/api/tracks/featured"],
    retry: false,
  });

  const { data: liveStream } = useQuery<LiveStream | null>({
    queryKey: ["/api/live-stream"],
    retry: false,
    refetchInterval: 30000,
  });

  const { data: trendingTracks } = useQuery<Track[]>({
    queryKey: ["/api/tracks/trending"],
    retry: false,
  });

  // Mock data for new sections
  const popularAlbums = [
    { id: 1, title: "Underground Frequencies", artist: "Deep Collective", year: "2024", tracks: 12, coverArt: undefined },
    { id: 2, title: "Neon Nights", artist: "Cyber Sound", year: "2024", tracks: 8, coverArt: undefined },
    { id: 3, title: "Warehouse Sessions", artist: "Industrial Beats", year: "2023", tracks: 10, coverArt: undefined },
    { id: 4, title: "Midnight Drive", artist: "Luna Bass", year: "2024", tracks: 6, coverArt: undefined },
  ];

  const popularArtists = [
    { id: 1, name: "Maya Rodriguez", genre: "Deep House", followers: "234K", avatar: undefined, verified: true },
    { id: 2, name: "Alex Chen", genre: "Tech House", followers: "189K", avatar: undefined, verified: true },
    { id: 3, name: "Jordan Smith", genre: "Progressive", followers: "156K", avatar: undefined, verified: false },
    { id: 4, name: "Priya Patel", genre: "Minimal", followers: "142K", avatar: undefined, verified: true },
  ];

  const genres = [
    { id: 1, name: "Deep House", trackCount: "2.4K", color: "bg-blue-600", description: "Soulful and atmospheric" },
    { id: 2, name: "Tech House", trackCount: "1.8K", color: "bg-red-600", description: "Driving and rhythmic" },
    { id: 3, name: "Progressive House", trackCount: "1.2K", color: "bg-purple-600", description: "Evolving and melodic" },
    { id: 4, name: "Minimal", trackCount: "890", color: "bg-green-600", description: "Clean and focused" },
  ];

  const moods = [
    { id: 1, name: "Late Night Vibes", icon: "🌙", trackCount: "1.5K", description: "Perfect for after hours" },
    { id: 2, name: "Workout Energy", icon: "⚡", trackCount: "980", description: "High-energy motivation" },
    { id: 3, name: "Chill Sessions", icon: "☁️", trackCount: "1.2K", description: "Relaxed and smooth" },
    { id: 4, name: "Dance Floor", icon: "💃", trackCount: "2.1K", description: "Club-ready bangers" },
  ];

  const editorPicks = [
    { id: 1, title: "Midnight Frequencies", artist: "Luna Bass", reason: "Perfect late-night vibes", duration: 347 },
    { id: 2, title: "Underground Pulse", artist: "Tech Warrior", reason: "Driving bassline excellence", duration: 412 },
    { id: 3, title: "Deep Current", artist: "Ocean Mind", reason: "Atmospheric masterpiece", duration: 298 },
    { id: 4, title: "City Lights", artist: "Neon Dreams", reason: "Peak-time energy", duration: 365 },
  ];

  const upcomingDJs = [
    { id: 1, name: "DJ Aurora", event: "Deep Sessions Live", time: "Tonight 9 PM", genre: "Deep House", listeners: 892 },
    { id: 2, name: "Techno Mike", event: "Underground Warehouse", time: "Tomorrow 8 PM", genre: "Techno", listeners: 1247 },
    { id: 3, name: "Progressive Sarah", event: "Journey Through Sound", time: "Wed 10 PM", genre: "Progressive", listeners: 654 },
    { id: 4, name: "Minimal Max", event: "Less Is More", time: "Thu 11 PM", genre: "Minimal", listeners: 423 },
  ];

  const quickGenres = [
    { name: "Deep House", count: 1247, color: "from-red-600 to-red-800" },
    { name: "Tech House", count: 892, color: "from-purple-600 to-purple-800" },
    { name: "Progressive", count: 634, color: "from-blue-600 to-blue-800" },
    { name: "Minimal", count: 421, color: "from-green-600 to-green-800" },
    { name: "Techno", count: 789, color: "from-yellow-600 to-yellow-800" },
    { name: "Melodic", count: 567, color: "from-pink-600 to-pink-800" },
  ];

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Top Navigation */}
      <nav className="bg-black/90 backdrop-blur-sm border-b border-gray-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <img 
                src="/attached_assets/Bb2_1754377368688.png" 
                alt="Best Beats Logo" 
                className="w-8 h-8 filter brightness-0 invert"
              />
              <div className="text-2xl font-bold cool-red-gradient bg-clip-text text-transparent">
                Best Beats
              </div>
            </div>

            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <a href="#" className="text-white hover:text-red-400 px-3 py-2 rounded-md text-sm font-medium">Home</a>
                <a href="#" className="text-gray-300 hover:text-red-400 px-3 py-2 rounded-md text-sm font-medium">Browse</a>
                <a href="#" className="text-gray-300 hover:text-red-400 px-3 py-2 rounded-md text-sm font-medium">Live</a>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Badge variant="destructive" className="hidden sm:block text-xs">
                FREE TIER
              </Badge>
              <Button 
                onClick={() => window.location.href = "/api/login"} 
                variant="outline" 
                className="border-gray-600 hidden sm:block"
              >
                Log In
              </Button>
              <Button 
                onClick={() => window.location.href = "/signup"} 
                className="cool-red-gradient hover:bg-red-700 text-white"
              >
                Sign Up
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Live Stream Banner */}
      {liveStream?.isLive && (
        <div className="cool-red-gradient p-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-3 h-3 bg-white rounded-full animate-pulse"></div>
              <span className="font-semibold">LIVE NOW</span>
              <span className="text-red-100">{liveStream.djName}</span>
              <span className="text-red-200 text-sm">{liveStream.title}</span>
            </div>
            <Button variant="secondary" className="bg-white/20 hover:bg-white/30">
              <Radio className="h-4 w-4 mr-2" />
              Watch Live
            </Button>
          </div>
        </div>
      )}

      <div className="flex max-w-7xl mx-auto">
        {/* Sidebar */}
        <aside className="w-80 bg-gray-800/50 min-h-screen p-6 border-r border-gray-700">
          {/* Quick Browse */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <Music className="h-5 w-5 mr-2 text-red-400" />
              Quick Browse
            </h3>
            <div className="space-y-2">
              {quickGenres.map((genre) => (
                <button
                  key={genre.name}
                  className="w-full text-left p-3 rounded-lg bg-gray-700/50 hover:bg-gray-700 transition-colors"
                >
                  <div className="flex justify-between items-center">
                    <span className="font-medium">{genre.name}</span>
                    <span className="text-sm text-gray-400">{genre.count}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Popular Artists */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <Star className="h-5 w-5 mr-2 text-red-400" />
              Popular Artists
            </h3>
            <div className="space-y-3">
              {popularArtists.slice(0, 5).map((artist) => (
                <div key={artist.id} className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-700/50 transition-colors cursor-pointer">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={artist.avatar} />
                    <AvatarFallback className="bg-gradient-to-br from-red-600 to-red-800">
                      {artist.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-1">
                      <p className="text-sm font-medium truncate">{artist.name}</p>
                      {artist.verified && (
                        <Crown className="h-3 w-3 text-yellow-400" />
                      )}
                    </div>
                    <p className="text-xs text-gray-400">{artist.followers} followers</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Upcoming DJs */}
          <div>
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-red-400" />
              Upcoming Live
            </h3>
            <div className="space-y-3">
              {upcomingDJs.slice(0, 4).map((dj) => (
                <div key={dj.id} className="p-3 rounded-lg bg-gray-700/30 border border-gray-600">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-sm">{dj.name}</span>
                    <Badge variant="outline" className="text-xs border-red-600 text-red-400">
                      <Clock className="h-3 w-3 mr-1" />
                      {dj.time}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-400 mb-1">{dj.event}</p>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-500">{dj.genre}</span>
                    <span className="text-gray-500">{dj.listeners} listeners</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {/* Hero Section */}
          <div className="text-center py-12 mb-12">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              The Underground <span className="cool-red-gradient bg-clip-text text-transparent">Music</span> Experience
            </h1>
            <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
              Discover the finest house music from emerging artists and established DJs. 
              Stream, share, and support the underground scene.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={() => setShowTierModal(true)}
                size="lg" 
                className="cool-red-gradient hover:bg-red-700 text-lg px-8 py-4"
              >
                <Music className="mr-2 h-5 w-5" />
                Choose Your Experience
              </Button>
              <Button 
                onClick={() => window.location.href = "/api/login"}
                variant="outline" 
                size="lg" 
                className="text-lg px-8 py-4 border-gray-600"
              >
                <Users className="mr-2 h-5 w-5" />
                Already a Member?
              </Button>
            </div>
          </div>

          {/* Trending Section */}
          {trendingTracks && trendingTracks.length > 0 && (
            <section className="mb-12">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-3xl font-bold flex items-center">
                  <TrendingUp className="h-8 w-8 mr-3 text-red-400" />
                  Trending Now
                </h2>
                <Button variant="link" className="text-red-400 hover:text-red-300">
                  View All
                </Button>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {trendingTracks.slice(0, 12).map((track, index) => (
                  <Card key={track.id} className="music-card bg-gray-800 border-gray-700 overflow-hidden relative group">
                    <div className="aspect-square bg-gray-700 relative">
                      {track.coverArtUrl ? (
                        <img 
                          src={track.coverArtUrl} 
                          alt={track.title}
                          className="w-full h-full object-cover" 
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center">
                          <Music className="h-8 w-8 text-white" />
                        </div>
                      )}
                      
                      {/* Trending Badge */}
                      <div className="absolute top-2 left-2">
                        <Badge className="bg-red-600 text-white text-xs">
                          #{index + 1}
                        </Badge>
                      </div>
                      
                      {/* Play Button Overlay */}
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button 
                          size="sm" 
                          className="w-12 h-12 rounded-full cool-red-gradient hover:bg-red-700"
                          onClick={() => handleTrackPlay(track)}
                        >
                          <Play className="h-4 w-4 text-white" />
                        </Button>
                      </div>
                    </div>
                    
                    <CardContent className="p-3">
                      <h3 className="font-semibold text-sm truncate">{track.title}</h3>
                      <p className="text-gray-400 text-xs truncate">{track.artist}</p>
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center space-x-1">
                          <TrendingUp className="h-3 w-3 text-red-400" />
                          <span className="text-xs text-red-400">Trending</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Heart className="h-3 w-3 text-gray-400 hover:text-red-400 cursor-pointer" />
                          <Share2 className="h-3 w-3 text-gray-400 hover:text-blue-400 cursor-pointer" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>
          )}

          {/* Popular Albums Section */}
          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-3xl font-bold flex items-center">
                <Disc className="h-8 w-8 mr-3 text-purple-400" />
                Popular Albums
              </h2>
              <Button variant="link" className="text-red-400 hover:text-red-300">
                View All
              </Button>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {popularAlbums.map((album) => (
                <Card key={album.id} className="music-card bg-gray-800 border-gray-700 overflow-hidden relative group">
                  <div className="aspect-square bg-gray-700 relative">
                    <div className="w-full h-full bg-gradient-to-br from-purple-600 to-purple-800 flex items-center justify-center">
                      <Disc className="h-12 w-12 text-white" />
                    </div>
                    
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button 
                        size="sm" 
                        className="w-12 h-12 rounded-full cool-red-gradient hover:bg-red-700"
                      >
                        <Play className="h-4 w-4 text-white" />
                      </Button>
                    </div>
                  </div>
                  
                  <CardContent className="p-3">
                    <h3 className="font-semibold text-sm truncate">{album.title}</h3>
                    <p className="text-gray-400 text-xs truncate">{album.artist}</p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-gray-500">{album.year}</span>
                      <span className="text-xs text-gray-500">{album.tracks} tracks</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          {/* Popular Artists Section */}
          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-3xl font-bold flex items-center">
                <UserCheck className="h-8 w-8 mr-3 text-blue-400" />
                Popular Artists
              </h2>
              <Button variant="link" className="text-red-400 hover:text-red-300">
                View All
              </Button>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {popularArtists.map((artist) => (
                <Card key={artist.id} className="music-card bg-gray-800 border-gray-700 overflow-hidden relative group">
                  <div className="aspect-square bg-gray-700 relative">
                    <div className="w-full h-full bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center">
                      <div className="text-4xl font-bold text-white">
                        {artist.name.split(' ').map(n => n[0]).join('')}
                      </div>
                    </div>
                    
                    {artist.verified && (
                      <div className="absolute top-2 right-2">
                        <Crown className="h-5 w-5 text-yellow-400" />
                      </div>
                    )}
                  </div>
                  
                  <CardContent className="p-3">
                    <h3 className="font-semibold text-sm truncate">{artist.name}</h3>
                    <p className="text-gray-400 text-xs truncate">{artist.genre}</p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-gray-500">{artist.followers} followers</span>
                      <Heart className="h-3 w-3 text-gray-400 hover:text-red-400 cursor-pointer" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          {/* Genres Section */}
          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-3xl font-bold flex items-center">
                <Palette className="h-8 w-8 mr-3 text-green-400" />
                Browse Genres
              </h2>
              <Button variant="link" className="text-red-400 hover:text-red-300">
                View All
              </Button>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {genres.map((genre) => (
                <Card key={genre.id} className="music-card bg-gray-800 border-gray-700 overflow-hidden relative group cursor-pointer hover:scale-105 transition-transform">
                  <div className="aspect-square relative">
                    <div className={`w-full h-full ${genre.color} flex flex-col items-center justify-center text-white`}>
                      <Music className="h-12 w-12 mb-2" />
                      <h3 className="font-bold text-lg text-center">{genre.name}</h3>
                      <p className="text-sm opacity-80 text-center">{genre.description}</p>
                    </div>
                    
                    <div className="absolute bottom-2 right-2">
                      <Badge className="bg-black/60 text-white text-xs">
                        {genre.trackCount} tracks
                      </Badge>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </section>

          {/* Moods Section */}
          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-3xl font-bold flex items-center">
                <Headphones className="h-8 w-8 mr-3 text-orange-400" />
                Mood Playlists
              </h2>
              <Button variant="link" className="text-red-400 hover:text-red-300">
                View All
              </Button>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {moods.map((mood) => (
                <Card key={mood.id} className="music-card bg-gray-800 border-gray-700 overflow-hidden relative group cursor-pointer hover:scale-105 transition-transform">
                  <div className="aspect-square relative">
                    <div className="w-full h-full bg-gradient-to-br from-orange-600 to-orange-800 flex flex-col items-center justify-center text-white">
                      <div className="text-4xl mb-2">{mood.icon}</div>
                      <h3 className="font-bold text-lg text-center">{mood.name}</h3>
                      <p className="text-sm opacity-80 text-center px-2">{mood.description}</p>
                    </div>
                    
                    <div className="absolute bottom-2 right-2">
                      <Badge className="bg-black/60 text-white text-xs">
                        {mood.trackCount} tracks
                      </Badge>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </section>

          {/* Featured Section */}
          {featuredTracks && featuredTracks.length > 0 && (
            <section className="mb-12">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-3xl font-bold flex items-center">
                  <Star className="h-8 w-8 mr-3 text-yellow-400" />
                  Featured Tracks
                </h2>
                <Button variant="link" className="text-red-400 hover:text-red-300">
                  View All
                </Button>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {featuredTracks.slice(0, 12).map((track) => (
                  <Card key={track.id} className="music-card bg-gray-800 border-gray-700 overflow-hidden relative group">
                    <div className="aspect-square bg-gray-700 relative">
                      {track.coverArtUrl ? (
                        <img 
                          src={track.coverArtUrl} 
                          alt={track.title}
                          className="w-full h-full object-cover" 
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-yellow-600 to-yellow-800 flex items-center justify-center">
                          <Music className="h-8 w-8 text-white" />
                        </div>
                      )}
                      
                      {/* Featured Badge */}
                      <div className="absolute top-2 left-2">
                        <Badge className="bg-yellow-600 text-white text-xs">
                          <Star className="h-3 w-3 mr-1" />
                          Featured
                        </Badge>
                      </div>
                      
                      {/* Tier Restriction Overlay for Free Users */}
                      {track.accessType === 'paid' && (
                        <div className="absolute inset-0 tier-overlay bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <div className="text-center">
                            <div className="w-8 h-8 rounded-full bg-red-600 flex items-center justify-center mb-2 mx-auto">
                              <span className="text-white text-xs">🔒</span>
                            </div>
                            <p className="text-sm font-medium">Premium Only</p>
                          </div>
                        </div>
                      )}
                      
                      {/* Play Button Overlay */}
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button size="sm" className="w-12 h-12 rounded-full cool-red-gradient hover:bg-red-700">
                          <Play className="h-4 w-4 text-white" />
                        </Button>
                      </div>
                    </div>
                    
                    <CardContent className="p-3">
                      <h3 className="font-semibold text-sm truncate">{track.title}</h3>
                      <p className="text-gray-400 text-xs truncate">{track.artist}</p>
                      
                      {/* Preview indicator for free users */}
                      {track.accessType === 'preview' && (
                        <Badge variant="outline" className="mt-2 text-xs border-yellow-600 text-yellow-400">
                          Preview
                        </Badge>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>
          )}

          {/* Editor's Picks */}
          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-3xl font-bold flex items-center">
                <Award className="h-8 w-8 mr-3 text-purple-400" />
                Editor's Picks
              </h2>
              <Button variant="link" className="text-red-400 hover:text-red-300">
                View All
              </Button>
            </div>
            
            <div className="grid md:grid-cols-2 gap-4">
              {editorPicks.map((pick) => (
                <Card key={pick.id} className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-purple-600 to-purple-800 flex items-center justify-center">
                        <Award className="h-8 w-8 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{pick.title}</h3>
                        <p className="text-gray-400">{pick.artist}</p>
                        <p className="text-sm text-purple-400 italic mt-1">"{pick.reason}"</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-gray-400">
                          {Math.floor(pick.duration / 60)}:{(pick.duration % 60).toString().padStart(2, '0')}
                        </span>
                        <Button size="sm" className="w-10 h-10 rounded-full cool-red-gradient hover:bg-red-700">
                          <Play className="h-4 w-4 text-white" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          {/* Live Stream Embed */}
          {liveStream && (
            <section className="mb-12">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-3xl font-bold flex items-center">
                  <Radio className="h-8 w-8 mr-3 text-green-400" />
                  Live DJ Session
                </h2>
              </div>
              
              <Card className="bg-gray-800 border-gray-700 overflow-hidden shadow-2xl">
                <div className="aspect-video bg-black relative">
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center mb-4 mx-auto animate-pulse">
                        <Radio className="text-white h-8 w-8" />
                      </div>
                      <h3 className="text-xl font-bold mb-2">Live DJ Set</h3>
                      <p className="text-gray-300">Experience the underground</p>
                      <Button className="mt-4 cool-red-gradient">
                        <Volume2 className="h-4 w-4 mr-2" />
                        Join Live Session
                      </Button>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold">{liveStream.title}</h3>
                      <p className="text-gray-400">{liveStream.description}</p>
                      <p className="text-sm text-green-400 mt-1">DJ {liveStream.djName}</p>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <span className="text-red-400 text-sm animate-pulse">●</span>
                        <span className="text-sm">{liveStream.viewerCount} watching</span>
                      </div>
                      <Button variant="outline" className="border-gray-600">
                        <Heart className="h-4 w-4 mr-2" />
                        Follow DJ
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </section>
          )}

          {/* CTA Section */}
          <section className="py-16 text-center">
            <div className="cool-red-gradient rounded-2xl p-12">
              <h2 className="text-4xl font-bold mb-4">Ready to Join the Underground?</h2>
              <p className="text-red-100 text-lg mb-8 max-w-2xl mx-auto">
                Get unlimited access to thousands of house tracks, exclusive DJ sets, 
                and join a community of music lovers.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  onClick={() => setShowTierModal(true)}
                  size="lg" 
                  className="bg-white text-red-600 hover:bg-gray-100 font-semibold"
                >
                  Choose Your Plan
                </Button>
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="border-white text-white hover:bg-white/10"
                >
                  Learn More
                </Button>
              </div>
            </div>
          </section>
        </main>
      </div>

      {/* Fixed Audio Player at Bottom */}
      {currentTrack && (
        <div className="fixed bottom-0 left-0 right-0 z-50">
          <AudioPlayer
            track={currentTrack}
            onPlay={(trackId) => console.log(`Playing track: ${trackId}`)}
            className="border-t border-gray-700 rounded-none"
          />
        </div>
      )}

      {/* Tier Features Section for Non-Users */}
      {!user && (
        <section className="bg-gray-800/50 py-12 mt-12">
          <div className="max-w-4xl mx-auto px-4">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-4">Choose Your Experience</h2>
              <p className="text-gray-400">Different tiers unlock different features</p>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              <TierFeaturesDisplay tier="free" />
              <TierFeaturesDisplay tier="subscriber" />
              <TierFeaturesDisplay tier="prepaid" />
            </div>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="bg-black border-t border-gray-800 mt-20">
        <div className="max-w-7xl mx-auto px-4 py-16">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Brand Section */}
            <div className="md:col-span-1">
              <div className="flex items-center space-x-3 mb-6">
                <img 
                  src={bestBeatsLogo} 
                  alt="Best Beats Logo" 
                  className="w-8 h-8 filter brightness-0 invert"
                />
                <div className="text-2xl font-bold cool-red-gradient bg-clip-text text-transparent">
                  Best Beats
                </div>
              </div>
              <p className="text-gray-400 mb-6 leading-relaxed">
                The underground house music platform for discovering, streaming, and supporting emerging artists and established DJs worldwide.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-red-400 transition-colors">
                  <Instagram className="h-5 w-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-red-400 transition-colors">
                  <Twitter className="h-5 w-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-red-400 transition-colors">
                  <Facebook className="h-5 w-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-red-400 transition-colors">
                  <Youtube className="h-5 w-5" />
                </a>
              </div>
            </div>

            {/* Music Section */}
            <div>
              <h3 className="text-white font-semibold mb-4 flex items-center">
                <Music className="h-4 w-4 mr-2 text-red-400" />
                Discover
              </h3>
              <ul className="space-y-3">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Trending Tracks</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">New Releases</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Top Charts</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Genres</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Live Sessions</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">DJ Mixes</a></li>
              </ul>
            </div>

            {/* Community Section */}
            <div>
              <h3 className="text-white font-semibold mb-4 flex items-center">
                <Users className="h-4 w-4 mr-2 text-red-400" />
                Community
              </h3>
              <ul className="space-y-3">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Artists</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">DJs</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Upload Music</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Playlists</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Following</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Events</a></li>
              </ul>
            </div>

            {/* Support Section */}
            <div>
              <h3 className="text-white font-semibold mb-4 flex items-center">
                <Heart className="h-4 w-4 mr-2 text-red-400" />
                Support
              </h3>
              <ul className="space-y-3">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Cookie Policy</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">DMCA</a></li>
              </ul>
            </div>
          </div>

          {/* Contact Info */}
          <div className="border-t border-gray-800 mt-12 pt-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-red-400" />
                <div>
                  <p className="text-white font-medium">Email</p>
                  <p className="text-gray-400">hello@bestbeats.com</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-red-400" />
                <div>
                  <p className="text-white font-medium">Support</p>
                  <p className="text-gray-400">+1 (555) 123-BEAT</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-red-400" />
                <div>
                  <p className="text-white font-medium">Location</p>
                  <p className="text-gray-400">Underground, Worldwide</p>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="border-t border-gray-800 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-gray-400 text-sm mb-4 md:mb-0">
                © 2025 Best Beats. All rights reserved. Feel the underground.
              </p>
              <div className="flex items-center space-x-6">
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">About</a>
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Careers</a>
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Press</a>
                <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">API</a>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* Tier Selection Modal */}
      <TierSelectionModal
        isOpen={showTierModal}
        onClose={() => setShowTierModal(false)}
        onTierSelected={(tier) => {
          setShowTierModal(false);
          // Redirect to signup with selected tier
          window.location.href = `/signup?tier=${tier}`;
        }}
      />
    </div>
  );
}