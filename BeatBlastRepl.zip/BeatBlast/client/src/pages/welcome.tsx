import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Music, Star, Crown, Check, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Welcome() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedTier, setSelectedTier] = useState<string>("");
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    // Get tier from sessionStorage if available
    const storedTier = sessionStorage.getItem('selectedTier');
    if (storedTier) {
      setSelectedTier(storedTier);
      sessionStorage.removeItem('selectedTier'); // Clean up
    } else {
      setSelectedTier('subscriber'); // Default to free tier
    }
  }, []);

  const updateTierMutation = useMutation({
    mutationFn: async (tier: string) => {
      await apiRequest("POST", "/api/auth/set-tier", { tier });
    },
    onSuccess: () => {
      setIsComplete(true);
      toast({
        title: "Welcome to Best Beats!",
        description: "Your account has been set up successfully.",
      });
      // Redirect to home after a short delay
      setTimeout(() => {
        window.location.href = "/";
      }, 2000);
    },
    onError: (error) => {
      toast({
        title: "Setup Error",
        description: "There was an issue setting up your account. Please try again.",
        variant: "destructive",
      });
      console.error("Error setting tier:", error);
    },
  });

  const handleFinishSetup = () => {
    updateTierMutation.mutate(selectedTier);
  };

  const tiers = {
    subscriber: {
      name: "Free Subscriber",
      price: "Free",
      description: "Perfect for discovering new music",
      icon: Music,
      color: "from-green-600 to-green-800"
    },
    prepaid: {
      name: "Premium",
      price: "R25/month",
      description: "Unlimited access to the underground scene",
      icon: Star,
      color: "from-red-600 to-red-800"
    },
    contributor: {
      name: "Contributor",
      price: "R45/month",
      description: "For artists and music creators",
      icon: Crown,
      color: "from-purple-600 to-purple-800"
    }
  };

  const currentTier = tiers[selectedTier as keyof typeof tiers];

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p>Setting up your account...</p>
        </div>
      </div>
    );
  }

  if (isComplete) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <Check className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold mb-4">Welcome to Best Beats!</h1>
          <p className="text-gray-300 mb-6">
            Your {currentTier?.name} account is ready. Redirecting you to start discovering amazing house music...
          </p>
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div className="bg-red-600 h-2 rounded-full animate-pulse" style={{ width: '100%' }}></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Navigation */}
      <nav className="bg-black/90 backdrop-blur-sm border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="text-2xl font-bold cool-red-gradient bg-clip-text text-transparent">
              Best Beats
            </div>
            <Badge variant="outline" className="border-green-600 text-green-400">
              Account Setup
            </Badge>
          </div>
        </div>
      </nav>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Welcome Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4">
            Welcome, <span className="cool-red-gradient bg-clip-text text-transparent">{user.firstName || 'Music Lover'}</span>!
          </h1>
          <p className="text-xl text-gray-300">
            Let's finish setting up your Best Beats account
          </p>
        </div>

        {/* Selected Tier Display */}
        {currentTier && (
          <Card className="bg-gray-800 border-gray-700 mb-8">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${currentTier.color} flex items-center justify-center`}>
                  <currentTier.icon className="h-8 w-8 text-white" />
                </div>
              </div>
              <CardTitle className="text-2xl">{currentTier.name}</CardTitle>
              <div className="text-2xl font-bold cool-red-gradient bg-clip-text text-transparent">
                {currentTier.price}
              </div>
              <p className="text-gray-400">{currentTier.description}</p>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <p className="text-sm text-gray-400 mb-6">
                  You selected the {currentTier.name} plan. You can change this anytime from your account settings.
                </p>
                
                <Button 
                  onClick={handleFinishSetup}
                  disabled={updateTierMutation.isPending}
                  size="lg" 
                  className="cool-red-gradient hover:bg-red-700 w-full font-semibold"
                >
                  {updateTierMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Setting up your account...
                    </>
                  ) : (
                    <>
                      <Music className="mr-2 h-5 w-5" />
                      Complete Setup & Start Listening
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* What's Next */}
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">What's next?</h3>
            <div className="space-y-3 text-sm text-gray-300">
              <div className="flex items-center">
                <Check className="h-4 w-4 text-green-400 mr-3" />
                <span>Explore curated house music collections</span>
              </div>
              <div className="flex items-center">
                <Check className="h-4 w-4 text-green-400 mr-3" />
                <span>Follow your favorite underground artists</span>
              </div>
              <div className="flex items-center">
                <Check className="h-4 w-4 text-green-400 mr-3" />
                <span>Join live DJ sessions and community events</span>
              </div>
              <div className="flex items-center">
                <Check className="h-4 w-4 text-green-400 mr-3" />
                <span>Discover trending tracks before they go mainstream</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}