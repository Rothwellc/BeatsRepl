import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Check, Music, Star, Crown, Users } from "lucide-react";
import TierSelectionModal from "@/components/tier-selection-modal";

export default function Signup() {
  const [selectedTier, setSelectedTier] = useState("subscriber");
  const [showTierModal, setShowTierModal] = useState(false);

  useEffect(() => {
    // Show tier selection modal on page load
    const timer = setTimeout(() => {
      setShowTierModal(true);
    }, 500); // Small delay for better UX

    return () => clearTimeout(timer);
  }, []);

  const tiers = [
    {
      id: "subscriber",
      name: "Free Subscriber",
      price: "Free",
      description: "Get started with house music discovery",
      features: [
        "30-second track previews",
        "Basic music discovery",
        "Community access",
        "Email notifications",
        "Social sharing"
      ],
      color: "border-green-600",
      icon: Users,
      popular: false
    },
    {
      id: "prepaid", 
      name: "Premium",
      price: "R25/month",
      description: "Full access to the underground scene",
      features: [
        "Unlimited full track streaming",
        "Background playback",
        "Create & share playlists",
        "Rating system access",
        "Ad-free experience",
        "High-quality audio",
        "Offline downloads"
      ],
      color: "border-red-600",
      icon: Star,
      popular: true
    },
    {
      id: "contributor",
      name: "Contributor",
      price: "R45/month", 
      description: "For artists and music creators",
      features: [
        "Everything in Premium",
        "Upload your own tracks",
        "Track analytics dashboard",
        "Direct fan engagement",
        "Revenue sharing",
        "Priority support",
        "Artist verification badge"
      ],
      color: "border-purple-600", 
      icon: Crown,
      popular: false
    }
  ];

  const handleSignup = () => {
    // Store selected tier in sessionStorage for after auth
    sessionStorage.setItem('selectedTier', selectedTier);
    // Redirect to Replit Auth with signup flow
    window.location.href = "/api/login?signup=true&tier=" + selectedTier;
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Navigation */}
      <nav className="bg-black/90 backdrop-blur-sm border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <a href="/" className="text-2xl font-bold cool-red-gradient bg-clip-text text-transparent">
                Best Beats
              </a>
            </div>
            <div className="flex items-center space-x-4">
              <a href="/" className="text-gray-300 hover:text-red-400 px-3 py-2 text-sm">
                Back to Home
              </a>
              <Button 
                onClick={() => window.location.href = "/api/login"} 
                variant="outline" 
                className="border-gray-600"
              >
                Already have an account?
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Join the <span className="cool-red-gradient bg-clip-text text-transparent">Underground</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Choose your membership tier and start discovering the finest house music from emerging artists and established DJs.
          </p>
        </div>

        {/* Tier Selection */}
        <div className="mb-8">
          <h2 className="text-2xl font-semibold text-center mb-8">Choose Your Experience</h2>
          
          <RadioGroup value={selectedTier} onValueChange={setSelectedTier} className="grid md:grid-cols-3 gap-6">
            {tiers.map((tier) => {
              const IconComponent = tier.icon;
              return (
                <div key={tier.id} className="relative">
                  <Label htmlFor={tier.id} className="cursor-pointer">
                    <Card className={`bg-gray-800 border-2 ${selectedTier === tier.id ? tier.color : 'border-gray-700'} hover:border-gray-600 transition-colors relative overflow-hidden`}>
                      {tier.popular && (
                        <div className="absolute top-0 right-0 bg-red-600 text-white px-3 py-1 text-xs font-semibold">
                          MOST POPULAR
                        </div>
                      )}
                      
                      <CardHeader className="text-center pb-2">
                        <div className="flex justify-center mb-4">
                          <div className={`w-16 h-16 rounded-full ${selectedTier === tier.id ? 'bg-gradient-to-br from-red-600 to-red-800' : 'bg-gray-700'} flex items-center justify-center transition-colors`}>
                            <IconComponent className="h-8 w-8 text-white" />
                          </div>
                        </div>
                        <CardTitle className="text-xl mb-2">{tier.name}</CardTitle>
                        <div className="text-3xl font-bold mb-2">
                          <span className="cool-red-gradient bg-clip-text text-transparent">{tier.price}</span>
                        </div>
                        <p className="text-gray-400 text-sm">{tier.description}</p>
                      </CardHeader>
                      
                      <CardContent className="pt-4">
                        <ul className="space-y-3 mb-6">
                          {tier.features.map((feature, index) => (
                            <li key={index} className="flex items-center text-sm">
                              <Check className="h-4 w-4 text-green-400 mr-3 flex-shrink-0" />
                              <span>{feature}</span>
                            </li>
                          ))}
                        </ul>
                        
                        <div className="flex items-center justify-center">
                          <RadioGroupItem 
                            value={tier.id} 
                            id={tier.id}
                            className="data-[state=checked]:bg-red-600 data-[state=checked]:border-red-600"
                          />
                        </div>
                      </CardContent>
                    </Card>
                  </Label>
                </div>
              );
            })}
          </RadioGroup>
        </div>

        {/* Selected Tier Summary */}
        <div className="text-center mb-8">
          <Card className="bg-gray-800 border-gray-700 max-w-md mx-auto">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-2">Selected Plan</h3>
              <div className="flex items-center justify-center space-x-2 mb-4">
                <Music className="h-5 w-5 text-red-400" />
                <span className="font-medium">
                  {tiers.find(t => t.id === selectedTier)?.name}
                </span>
                <Badge className="bg-red-600 text-white">
                  {tiers.find(t => t.id === selectedTier)?.price}
                </Badge>
              </div>
              <p className="text-sm text-gray-400 mb-4">
                {tiers.find(t => t.id === selectedTier)?.description}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Sign Up Button */}
        <div className="text-center">
          <Button 
            onClick={handleSignup}
            size="lg" 
            className="cool-red-gradient hover:bg-red-700 text-lg px-12 py-4 font-semibold"
          >
            <Music className="mr-2 h-5 w-5" />
            Create Account & Start Listening
          </Button>
          
          <p className="text-sm text-gray-400 mt-4 max-w-md mx-auto">
            By creating an account, you agree to our Terms of Service and Privacy Policy. 
            You can change your tier anytime from your account settings.
          </p>
        </div>

        {/* Feature Comparison */}
        <div className="mt-16">
          <h2 className="text-2xl font-semibold text-center mb-8">Why Choose Best Beats?</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Music className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Underground Focus</h3>
                <p className="text-gray-400 text-sm">
                  Discover exclusive house music tracks from emerging artists before they hit mainstream platforms.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Artist Support</h3>
                <p className="text-gray-400 text-sm">
                  Direct revenue sharing with artists. Your subscription directly supports the underground music scene.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Premium Experience</h3>
                <p className="text-gray-400 text-sm">
                  High-quality audio, curated playlists, and exclusive live DJ sessions from renowned underground artists.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Tier Selection Modal */}
      <TierSelectionModal
        isOpen={showTierModal}
        onClose={() => setShowTierModal(false)}
        onTierSelected={(tier) => {
          setSelectedTier(tier);
          setShowTierModal(false);
        }}
      />
    </div>
  );
}