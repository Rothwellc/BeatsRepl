import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import Navigation from "@/components/layout/navigation";
import TrackCard from "@/components/ui/track-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Filter, Music, TrendingUp } from "lucide-react";
import type { Track } from "@/types/music";

export default function Browse() {
  const { user, isLoading } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);

  const { data: tracks } = useQuery<Track[]>({
    queryKey: ["/api/tracks"],
    retry: false,
  });

  const { data: trendingTracks } = useQuery<Track[]>({
    queryKey: ["/api/tracks/trending"],
    retry: false,
  });

  const genres = [
    { name: "Deep House", count: 42, color: "from-red-600 to-red-800" },
    { name: "Tech House", count: 38, color: "from-purple-600 to-purple-800" },
    { name: "Progressive House", count: 25, color: "from-blue-600 to-blue-800" },
    { name: "Techno", count: 31, color: "from-green-600 to-green-800" },
    { name: "Minimal", count: 18, color: "from-yellow-600 to-yellow-800" },
    { name: "Melodic House", count: 22, color: "from-pink-600 to-pink-800" },
  ];

  const filteredTracks = tracks?.filter(track => {
    const matchesSearch = !searchQuery || 
      track.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      track.artist.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesGenre = !selectedGenre || track.genre === selectedGenre;
    
    return matchesSearch && matchesGenre;
  });

  const handlePlayTrack = (track: Track) => {
    // This would typically integrate with a global music player
    console.log("Playing track:", track.title);
  };

  if (isLoading) {
    return <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
      <div className="text-xl">Loading...</div>
    </div>;
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {user && <Navigation user={user} />}
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4">
            Browse <span className="cool-red-gradient bg-clip-text text-transparent">Music</span>
          </h1>
          <p className="text-gray-400 text-lg">
            Discover your next favorite track from our underground collection
          </p>
        </div>

        {/* Search and Filters */}
        <div className="mb-8">
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Search tracks, artists, or genres..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <Button variant="outline" className="border-gray-600">
                  <Filter className="h-4 w-4 mr-2" />
                  Filters
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="all" className="space-y-6">
          <TabsList className="bg-gray-800 border-gray-700">
            <TabsTrigger value="all" className="data-[state=active]:bg-red-600">
              All Tracks
            </TabsTrigger>
            <TabsTrigger value="trending" className="data-[state=active]:bg-red-600">
              <TrendingUp className="h-4 w-4 mr-2" />
              Trending
            </TabsTrigger>
            <TabsTrigger value="genres" className="data-[state=active]:bg-red-600">
              Genres
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-6">
            {selectedGenre && (
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-400">Filtered by:</span>
                  <Badge variant="secondary" className="bg-red-600 text-white">
                    {selectedGenre}
                  </Badge>
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setSelectedGenre(null)}
                  className="border-gray-600"
                >
                  Clear Filter
                </Button>
              </div>
            )}
            
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {filteredTracks?.map((track) => (
                <TrackCard 
                  key={track.id} 
                  track={track} 
                  userTier={user?.tier || 'free'} 
                  onPlay={() => handlePlayTrack(track)}
                />
              ))}
            </div>
            
            {filteredTracks?.length === 0 && (
              <div className="text-center py-12">
                <Music className="h-12 w-12 text-gray-500 mx-auto mb-4" />
                <p className="text-gray-400">No tracks found matching your search</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="trending" className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {trendingTracks?.map((track) => (
                <TrackCard 
                  key={track.id} 
                  track={track} 
                  userTier={user?.tier || 'free'} 
                  onPlay={() => handlePlayTrack(track)}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="genres" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {genres.map((genre) => (
                <Card 
                  key={genre.name} 
                  className="bg-gray-800 border-gray-700 cursor-pointer hover:bg-gray-700 transition-colors"
                  onClick={() => setSelectedGenre(genre.name)}
                >
                  <CardContent className="p-6">
                    <div className={`w-full h-32 bg-gradient-to-br ${genre.color} rounded-lg mb-4 flex items-center justify-center`}>
                      <Music className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-lg font-semibold mb-1">{genre.name}</h3>
                    <p className="text-gray-400 text-sm">{genre.count} tracks</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}