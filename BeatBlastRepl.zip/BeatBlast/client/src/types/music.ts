export interface Track {
  id: string;
  title: string;
  artist: string;
  genre: string;
  duration: number;
  audioUrl: string;
  coverArtUrl?: string;
  contributorId?: string;
  isPreview: boolean;
  accessType: 'free' | 'paid' | 'preview';
  status: 'pending' | 'approved' | 'rejected';
  playCount: number;
  averageRating: string;
  ratingCount: number;
  featuredUntil?: string;
  createdAt: string;
  updatedAt: string;
}

export interface User {
  id: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
  tier: 'free' | 'subscriber' | 'prepaid' | 'contributor' | 'admin';
  subscriptionExpiry?: string;
  createdAt: string;
  updatedAt: string;
}

export interface LiveStream {
  id: string;
  djName: string;
  title: string;
  description?: string;
  streamUrl?: string;
  isLive: boolean;
  viewerCount: number;
  startedAt?: string;
  endedAt?: string;
  createdAt: string;
}

export interface Rating {
  id: string;
  userId: string;
  trackId: string;
  score: number;
  createdAt: string;
}

export type UserTier = User['tier'];
